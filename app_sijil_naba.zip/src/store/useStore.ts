import { create } from 'zustand';

export interface Beneficiary {
  id: string;
  name: string;
  phone: string;
  number: string;
  age: string;
  district: string;
  startDate: string;
  endDate: string;
  notes: string;
  groupId: string;
  projectId: string;
  status: 'active' | 'ended' | 'archived';
  createdAt: string;
  fileData?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'paused' | 'ended';
  startDate: string;
  endDate: string;
  protectionType?: 'pin' | 'password';
  credential?: string;
  locked?: boolean;
  coverImage?: string;
  createdAt: string;
}

export interface Group {
  id: string;
  name: string;
  projectId: string;
  description: string;
  color: string;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  beneficiaryId: string;
  groupId: string;
  date: string;
  status: 'present' | 'absent' | 'late';
  notes: string;
  createdAt: string;
  lockedAt?: string;
}

export interface ActivityLogEntry {
  id: string;
  action: string;
  details: string;
  timestamp: string;
  type: 'create' | 'update' | 'delete' | 'archive' | 'attendance' | 'restore';
  beneficiaryId?: string;
  field?: string;
  oldValue?: string;
  newValue?: string;
}

export interface BackupEntry {
  id: string;
  date: string;
  size: number;
  data: string;
}

interface AppSettings {
  primaryColor: string;
  autoSave: boolean;
  language: string;
  autoBackupEnabled: boolean;
  autoBackupInterval: number;
  lastBackup: string;
  autoArchiveEnabled: boolean;
  darkMode: boolean;
  hasSeenWelcome: boolean;
  lastVisitedPage: string;
}

interface UndoEntry {
  description: string;
  snapshot: string;
  timestamp: string;
}

interface AppState {
  beneficiaries: Beneficiary[];
  projects: Project[];
  groups: Group[];
  attendance: AttendanceRecord[];
  activityLog: ActivityLogEntry[];
  backups: BackupEntry[];
  settings: AppSettings;
  undoStack: UndoEntry[];

  currentPage: string;
  setCurrentPage: (page: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  currentProjectId: string;
  setCurrentProjectId: (id: string) => void;
  leaveProject: () => void;
  verifyProjectAccess: (projectId: string, credential: string) => boolean;
  createProtectedProject: (p: Omit<Project, 'id' | 'createdAt'>) => string;

  addBeneficiary: (b: Omit<Beneficiary, 'id' | 'createdAt'>) => void;
  updateBeneficiary: (id: string, b: Partial<Beneficiary>, silent?: boolean) => void;
  deleteBeneficiary: (id: string) => void;
  archiveBeneficiary: (id: string) => void;
  restoreBeneficiary: (id: string) => void;

  addProject: (p: Omit<Project, 'id' | 'createdAt'>) => void;
  updateProject: (id: string, p: Partial<Project>) => void;
  deleteProject: (id: string) => void;

  addGroup: (g: Omit<Group, 'id' | 'createdAt'>) => void;
  updateGroup: (id: string, g: Partial<Group>) => void;
  deleteGroup: (id: string) => void;
  distributeStudents: (mode: 'random' | 'age', projectId?: string) => void;

  addAttendance: (a: Omit<AttendanceRecord, 'id' | 'createdAt'>) => void;
  updateAttendance: (id: string, a: Partial<AttendanceRecord>) => void;
  isAttendanceLocked: (record: AttendanceRecord) => boolean;

  addLog: (action: string, details: string, type: ActivityLogEntry['type'], extra?: Partial<ActivityLogEntry>) => void;

  updateSettings: (s: Partial<AppSettings>) => void;
  toggleDarkMode: () => void;

  pushUndo: (description: string) => void;
  performUndo: () => void;

  createBackup: () => void;
  restoreBackup: (backupId: string) => void;
  deleteBackup: (id: string) => void;

  autoArchiveCheck: () => void;
}

const generateId = () => Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
const STORAGE_KEY = 'beneficiary-system-data';
const BACKUPS_KEY = 'beneficiary-system-backups';

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}

function loadBackups(): BackupEntry[] {
  try {
    const raw = localStorage.getItem(BACKUPS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

function saveState(state: Partial<AppState>) {
  try {
    const toSave = {
      beneficiaries: state.beneficiaries,
      projects: state.projects,
      groups: state.groups,
      attendance: state.attendance,
      activityLog: state.activityLog,
      settings: state.settings,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
  } catch {}
}

function saveBackups(backups: BackupEntry[]) {
  try {
    localStorage.setItem(BACKUPS_KEY, JSON.stringify(backups));
  } catch {}
}

const saved = loadState();

const defaultProjects: Project[] = saved?.projects || [];
const defaultGroups: Group[] = saved?.groups || [];
const defaultBeneficiaries: Beneficiary[] = saved?.beneficiaries || [];

export const useStore = create<AppState>((set, get) => ({
  beneficiaries: defaultBeneficiaries,
  projects: defaultProjects,
  groups: defaultGroups,
  attendance: saved?.attendance || [],
  activityLog: saved?.activityLog || [],
  backups: loadBackups(),
  undoStack: [],
  settings: saved?.settings || {
    primaryColor: '#2563eb',
    autoSave: true,
    language: 'ar',
    autoBackupEnabled: true,
    autoBackupInterval: 24,
    lastBackup: '',
    autoArchiveEnabled: true,
    darkMode: false,
    hasSeenWelcome: false,
    lastVisitedPage: 'dashboard',
  },

  currentPage: saved?.settings?.lastVisitedPage || 'dashboard',
  setCurrentPage: (page) => {
    set((state) => {
      const ns = { currentPage: page, sidebarOpen: false, settings: { ...state.settings, lastVisitedPage: page } };
      saveState(ns as any);
      return ns;
    });
  },
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  currentProjectId: '',
  setCurrentProjectId: (id) => {
    set({ currentProjectId: id, currentPage: 'dashboard', sidebarOpen: false });
    get().autoArchiveCheck();
  },
  leaveProject: () => set({ currentProjectId: '', currentPage: 'dashboard', sidebarOpen: false }),
  verifyProjectAccess: (projectId, credential) => {
    const project = get().projects.find((p) => p.id === projectId);
    if (!project || project.locked) return false;
    const expected = project.credential || '';
    const ok = expected ? expected === credential : true;
    if (ok) get().setCurrentProjectId(projectId);
    return ok;
  },
  createProtectedProject: (p) => {
    const newP: Project = { ...p, id: generateId(), createdAt: new Date().toISOString() };
    set((s) => {
      const ns = { projects: [...s.projects, newP], currentProjectId: newP.id, currentPage: 'dashboard' };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('إضافة مشروع', `تم إنشاء المشروع: ${p.name}`, 'create');
    return newP.id;
  },

  addBeneficiary: (b) => {
    get().pushUndo('إضافة مستفيد');
    const newB: Beneficiary = { ...b, id: generateId(), createdAt: new Date().toISOString() };
    set((s) => {
      const ns = { beneficiaries: [...s.beneficiaries, newB] };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('إضافة مستفيد', `تمت إضافة المستفيد: ${b.name}`, 'create', { beneficiaryId: newB.id });
  },

  updateBeneficiary: (id, b, silent) => {
    if (!silent) get().pushUndo('تعديل مستفيد');
    const old = get().beneficiaries.find((x) => x.id === id);
    set((s) => {
      const ns = { beneficiaries: s.beneficiaries.map((x) => (x.id === id ? { ...x, ...b } : x)) };
      saveState({ ...s, ...ns });
      return ns;
    });
    if (!silent && old) {
      const changes = Object.keys(b).filter((k) => k !== 'id' && k !== 'createdAt');
      const fieldLabels: Record<string, string> = {
        name: 'الاسم', phone: 'الجوال', number: 'الرقم', age: 'العمر', district: 'الحي',
        startDate: 'تاريخ البداية', endDate: 'تاريخ النهاية', notes: 'ملاحظات',
        groupId: 'المجموعة', projectId: 'المشروع', status: 'الحالة',
      };
      changes.forEach((field) => {
        get().addLog(
          'تعديل بيانات مستفيد',
          `تعديل ${fieldLabels[field] || field} للمستفيد: ${old.name}`,
          'update',
          {
            beneficiaryId: id,
            field,
            oldValue: String((old as any)[field] || ''),
            newValue: String((b as any)[field] || ''),
          }
        );
      });
    }
  },

  deleteBeneficiary: (id) => {
    get().pushUndo('حذف مستفيد');
    const b = get().beneficiaries.find((x) => x.id === id);
    set((s) => {
      const ns = { beneficiaries: s.beneficiaries.filter((x) => x.id !== id) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('حذف مستفيد', `تم حذف المستفيد: ${b?.name}`, 'delete', { beneficiaryId: id });
  },

  archiveBeneficiary: (id) => {
    const b = get().beneficiaries.find((x) => x.id === id);
    set((s) => {
      const ns = { beneficiaries: s.beneficiaries.map((x) => (x.id === id ? { ...x, status: 'archived' as const } : x)) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('أرشفة مستفيد', `تمت أرشفة المستفيد: ${b?.name}`, 'archive', { beneficiaryId: id });
  },

  restoreBeneficiary: (id) => {
    const b = get().beneficiaries.find((x) => x.id === id);
    set((s) => {
      const ns = { beneficiaries: s.beneficiaries.map((x) => (x.id === id ? { ...x, status: 'active' as const } : x)) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('استعادة مستفيد', `تمت استعادة المستفيد: ${b?.name}`, 'restore', { beneficiaryId: id });
  },

  addProject: (p) => {
    const newP: Project = { ...p, id: generateId(), createdAt: new Date().toISOString() };
    set((s) => {
      const ns = { projects: [...s.projects, newP] };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('إضافة مشروع', `تمت إضافة المشروع: ${p.name}`, 'create');
  },

  updateProject: (id, p) => {
    set((s) => {
      const ns = { projects: s.projects.map((x) => (x.id === id ? { ...x, ...p } : x)) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('تعديل مشروع', `تم تعديل بيانات المشروع`, 'update');
  },

  deleteProject: (id) => {
    const p = get().projects.find((x) => x.id === id);
    set((s) => {
      const ns = { projects: s.projects.filter((x) => x.id !== id) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('حذف مشروع', `تم حذف المشروع: ${p?.name}`, 'delete');
  },

  addGroup: (g) => {
    const newG: Group = { ...g, id: generateId(), createdAt: new Date().toISOString() };
    set((s) => {
      const ns = { groups: [...s.groups, newG] };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('إضافة مجموعة', `تمت إضافة المجموعة: ${g.name}`, 'create');
  },

  updateGroup: (id, g) => {
    set((s) => {
      const ns = { groups: s.groups.map((x) => (x.id === id ? { ...x, ...g } : x)) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('تعديل مجموعة', `تم تعديل بيانات المجموعة`, 'update');
  },

  deleteGroup: (id) => {
    const g = get().groups.find((x) => x.id === id);
    set((s) => {
      const ns = { groups: s.groups.filter((x) => x.id !== id) };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('حذف مجموعة', `تم حذف المجموعة: ${g?.name}`, 'delete');
  },

  distributeStudents: (mode, projectId) => {
    const targetProjectId = projectId || get().currentProjectId;
    const projectGroups = get().groups.filter((g) => !targetProjectId || g.projectId === targetProjectId);
    const students = get().beneficiaries.filter(
      (b) => b.status === 'active' && (!targetProjectId || b.projectId === targetProjectId)
    );
    if (projectGroups.length === 0 || students.length === 0) return;

    get().pushUndo(mode === 'random' ? 'توزيع عشوائي' : 'توزيع حسب العمر');

    let ordered = [...students];
    if (mode === 'random') {
      ordered = ordered.sort(() => Math.random() - 0.5);
    } else {
      // Balance ages by placing older/younger alternately across groups.
      ordered = ordered.sort((a, b) => (Number(b.age) || 0) - (Number(a.age) || 0));
    }

    const assignments = new Map<string, string>();
    if (mode === 'age') {
      const buckets = projectGroups.map(() => ({ totalAge: 0, count: 0, ids: [] as string[] }));
      ordered.forEach((student) => {
        const age = Number(student.age) || 0;
        const targetIndex = buckets
          .map((bucket, index) => ({ index, avg: bucket.count ? bucket.totalAge / bucket.count : 0, count: bucket.count }))
          .sort((a, b) => a.count - b.count || a.avg - b.avg)[0].index;
        buckets[targetIndex].totalAge += age;
        buckets[targetIndex].count += 1;
        buckets[targetIndex].ids.push(student.id);
        assignments.set(student.id, projectGroups[targetIndex].id);
      });
    } else {
      ordered.forEach((student, index) => {
        assignments.set(student.id, projectGroups[index % projectGroups.length].id);
      });
    }

    set((s) => {
      const ns = {
        beneficiaries: s.beneficiaries.map((b) =>
          assignments.has(b.id) ? { ...b, groupId: assignments.get(b.id)! } : b
        ),
      };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog(
      'توزيع المستفيدين',
      mode === 'random' ? 'تم التوزيع العشوائي بالتساوي' : 'تم التوزيع حسب العمر مع موازنة الأعمار',
      'update'
    );
  },

  addAttendance: (a) => {
    const newA: AttendanceRecord = { ...a, id: generateId(), createdAt: new Date().toISOString() };
    set((s) => {
      const ns = { attendance: [...s.attendance, newA] };
      saveState({ ...s, ...ns });
      return ns;
    });
    const ben = get().beneficiaries.find((b) => b.id === a.beneficiaryId);
    const statusLabel = a.status === 'present' ? 'حاضر' : a.status === 'absent' ? 'غائب' : 'متأخر';
    get().addLog('تسجيل حضور', `تسجيل ${statusLabel} للمستفيد: ${ben?.name} - ${a.date}`, 'attendance', { beneficiaryId: a.beneficiaryId });
  },

  updateAttendance: (id, a) => {
    const record = get().attendance.find((x) => x.id === id);
    if (record && get().isAttendanceLocked(record)) return;
    set((s) => {
      const ns = { attendance: s.attendance.map((x) => (x.id === id ? { ...x, ...a } : x)) };
      saveState({ ...s, ...ns });
      return ns;
    });
    if (a.status) {
      const ben = get().beneficiaries.find((b) => b.id === record?.beneficiaryId);
      const statusLabel = a.status === 'present' ? 'حاضر' : a.status === 'absent' ? 'غائب' : 'متأخر';
      get().addLog('تعديل حضور', `تعديل حضور ${ben?.name} إلى ${statusLabel}`, 'attendance', { beneficiaryId: record?.beneficiaryId });
    }
  },

  isAttendanceLocked: (record) => {
    const created = new Date(record.createdAt).getTime();
    const now = Date.now();
    const hours24 = 24 * 60 * 60 * 1000;
    return (now - created) > hours24;
  },

  addLog: (action, details, type, extra) => {
    const entry: ActivityLogEntry = {
      id: generateId(),
      action,
      details,
      timestamp: new Date().toISOString(),
      type,
      ...extra,
    };
    set((s) => {
      const ns = { activityLog: [entry, ...s.activityLog].slice(0, 500) };
      saveState({ ...s, ...ns });
      return ns;
    });
  },

  updateSettings: (s) => {
    set((state) => {
      const ns = { settings: { ...state.settings, ...s } };
      saveState({ ...state, ...ns });
      return ns;
    });
  },

  toggleDarkMode: () => {
    const current = get().settings.darkMode;
    get().updateSettings({ darkMode: !current });
    if (!current) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  },

  pushUndo: (description) => {
    const state = get();
    // Only save the slice that's relevant to undoing student-related operations,
    // so it doesn't wipe out projects, groups, or attendance taken in between.
    const snapshot = JSON.stringify({
      beneficiaries: state.beneficiaries,
    });
    set((s) => ({
      undoStack: [...s.undoStack.slice(-19), { description, snapshot, timestamp: new Date().toISOString() }],
    }));
  },

  performUndo: () => {
    const { undoStack } = get();
    if (undoStack.length === 0) return;
    const last = undoStack[undoStack.length - 1];
    try {
      const data = JSON.parse(last.snapshot);
      set((s) => {
        const ns = {
          beneficiaries: data.beneficiaries || s.beneficiaries,
          undoStack: s.undoStack.slice(0, -1),
        };
        saveState({ ...s, ...ns });
        return ns;
      });
      get().addLog('تراجع', `تم التراجع عن: ${last.description}`, 'update');
    } catch {}
  },

  createBackup: () => {
    const state = get();
    const data = {
      beneficiaries: state.beneficiaries,
      projects: state.projects,
      groups: state.groups,
      attendance: state.attendance,
      activityLog: state.activityLog,
      settings: state.settings,
    };
    const dataStr = JSON.stringify(data);
    const backup: BackupEntry = {
      id: generateId(),
      date: new Date().toISOString(),
      size: new Blob([dataStr]).size,
      data: dataStr,
    };
    set((s) => {
      const newBackups = [backup, ...s.backups].slice(0, 10);
      saveBackups(newBackups);
      const ns = { backups: newBackups, settings: { ...s.settings, lastBackup: backup.date } };
      saveState({ ...s, ...ns });
      return ns;
    });
    get().addLog('نسخ احتياطي', 'تم إنشاء نسخة احتياطية', 'create');
  },

  restoreBackup: (backupId) => {
    const backup = get().backups.find((b) => b.id === backupId);
    if (!backup) return;
    try {
      const data = JSON.parse(backup.data);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      window.location.reload();
    } catch {}
  },

  deleteBackup: (id) => {
    set((s) => {
      const newBackups = s.backups.filter((b) => b.id !== id);
      saveBackups(newBackups);
      return { backups: newBackups };
    });
  },

  autoArchiveCheck: () => {
    const { settings, beneficiaries, projects } = get();
    if (!settings.autoArchiveEnabled) return;
    const today = new Date().toISOString().split('T')[0];

    // Archive active beneficiaries whose own end date has passed while their project is still active.
    beneficiaries.forEach((b) => {
      const project = projects.find((p) => p.id === b.projectId);
      if (b.status === 'active' && b.endDate && b.endDate < today && project?.status === 'active') {
        get().updateBeneficiary(b.id, { status: 'archived' }, true);
        get().addLog('أرشفة تلقائية', `انتهت فترة المستفيد وتم نقله للأرشيف: ${b.name}`, 'archive', { beneficiaryId: b.id });
      }
    });

    // Archive ended projects
    projects.forEach((p) => {
      if (p.status === 'active' && p.endDate && p.endDate < today) {
        get().updateProject(p.id, { status: 'ended' });
        get().addLog('أرشفة تلقائية', `انتهى المشروع: ${p.name}`, 'archive');
      }
    });
  },
}));
