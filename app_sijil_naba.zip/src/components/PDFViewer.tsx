import { useState, useRef, useCallback } from 'react';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Upload, FileText, RotateCcw, Loader2, ImageIcon } from 'lucide-react';

interface PDFViewerProps {
  onFileLoaded?: (dataUrl: string) => void;
}

let pdfjsLib: any = null;
async function loadPdfJs(): Promise<any> {
  if (pdfjsLib) return pdfjsLib;
  return new Promise((resolve, reject) => {
    if ((window as any).pdfjsLib) { pdfjsLib = (window as any).pdfjsLib; resolve(pdfjsLib); return; }
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    s.onload = () => { pdfjsLib = (window as any).pdfjsLib; pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'; resolve(pdfjsLib); };
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

export default function PDFViewer({ onFileLoaded }: PDFViewerProps) {
  const [pages, setPages] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [scale, setScale] = useState(1);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imgContainerRef = useRef<HTMLDivElement>(null);
  const pinchStartRef = useRef(0);
  const pinchScaleRef = useRef(1);

  // Convert single PDF page to image dataURL
  const pageToImage = useCallback(async (doc: any, pageNum: number): Promise<string> => {
    const page = await doc.getPage(pageNum);
    const vp = page.getViewport({ scale: 2.0 }); // high-res
    const canvas = document.createElement('canvas');
    canvas.width = vp.width;
    canvas.height = vp.height;
    const ctx = canvas.getContext('2d')!;
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    return canvas.toDataURL('image/jpeg', 0.92);
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if it's an image
    if (file.type.startsWith('image/')) {
      setLoading(true);
      setProgress('جاري تجهيز الصورة...');
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setPages([dataUrl]);
        setCurrentPage(0);
        setLoading(false);
        setProgress('');
        onFileLoaded?.(dataUrl);
      };
      reader.readAsDataURL(file);
      return;
    }

    // PDF processing
    if (!file.type.includes('pdf') && !file.name.endsWith('.pdf')) {
      return;
    }

    setLoading(true);
    setProgress('جاري تحميل المكتبة...');
    try {
      const pdfjs = await loadPdfJs();
      setProgress('جاري قراءة الملف...');
      const arrayBuffer = await file.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: arrayBuffer }).promise;
      const numPages = doc.numPages;

      const imageUrls: string[] = [];
      for (let i = 1; i <= numPages; i++) {
        setProgress(`جاري تحويل الصفحة ${i} من ${numPages}...`);
        const imgUrl = await pageToImage(doc, i);
        imageUrls.push(imgUrl);
      }

      setPages(imageUrls);
      setCurrentPage(0);
      setProgress('');

      // Store first page as file reference
      const reader = new FileReader();
      reader.onload = () => onFileLoaded?.(reader.result as string);
      reader.readAsDataURL(file);
    } catch (err) {
      console.error('PDF error:', err);
      setProgress('حدث خطأ في قراءة الملف');
      setTimeout(() => setProgress(''), 3000);
    } finally {
      setLoading(false);
    }
  };

  const goTo = (dir: number) => {
    const next = currentPage + dir;
    if (next >= 0 && next < pages.length) {
      setCurrentPage(next);
      imgContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getTouchDistance = (touches: React.TouchList) => {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) {
      pinchStartRef.current = getTouchDistance(e.touches);
      pinchScaleRef.current = scale;
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2 && pinchStartRef.current > 0) {
      e.preventDefault();
      const distance = getTouchDistance(e.touches);
      const nextScale = Math.max(0.7, Math.min(3, pinchScaleRef.current * (distance / pinchStartRef.current)));
      setScale(nextScale);
    }
  };

  return (
    <div className="rounded-2xl border overflow-hidden transition-colors" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>

      {/* Top bar */}
      <div className="border-b p-2.5 flex items-center justify-between gap-2 flex-wrap" style={{ backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)' }}>
        <button onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-2 px-3 py-2 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl text-xs sm:text-sm font-medium hover:shadow-lg transition-all active:scale-95">
          <Upload size={15} />
          رفع ملف PDF أو صورة
        </button>
        <input ref={fileInputRef} type="file" accept=".pdf,application/pdf,image/*" onChange={handleFileUpload} className="hidden" />

        {pages.length > 0 && (
          <div className="flex items-center gap-1.5">
            {/* Zoom */}
            <div className="flex items-center rounded-xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
              <button onClick={() => setScale((s) => Math.max(0.5, s - 0.2))} className="p-1.5 hover:bg-[var(--bg-card-hover)]"><ZoomOut size={14} style={{ color: 'var(--text-secondary)' }} /></button>
              <span className="px-1.5 text-[10px] font-bold min-w-[40px] text-center" style={{ color: 'var(--text-secondary)' }}>{Math.round(scale * 100)}%</span>
              <button onClick={() => setScale((s) => Math.min(3, s + 0.2))} className="p-1.5 hover:bg-[var(--bg-card-hover)]"><ZoomIn size={14} style={{ color: 'var(--text-secondary)' }} /></button>
              <button onClick={() => setScale(1)} className="p-1.5 hover:bg-[var(--bg-card-hover)] border-r" style={{ borderColor: 'var(--border-color)' }}><RotateCcw size={12} style={{ color: 'var(--text-secondary)' }} /></button>
            </div>
            {/* Pages */}
            {pages.length > 1 && (
              <div className="flex items-center rounded-xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
                <button onClick={() => goTo(-1)} disabled={currentPage <= 0} className="p-1.5 hover:bg-[var(--bg-card-hover)] disabled:opacity-30"><ChevronRight size={14} style={{ color: 'var(--text-secondary)' }} /></button>
                <span className="px-2 text-[10px] sm:text-xs font-bold" style={{ color: 'var(--text-primary)' }}>{currentPage + 1} / {pages.length}</span>
                <button onClick={() => goTo(1)} disabled={currentPage >= pages.length - 1} className="p-1.5 hover:bg-[var(--bg-card-hover)] disabled:opacity-30"><ChevronLeft size={14} style={{ color: 'var(--text-secondary)' }} /></button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Image display */}
      <div
        ref={imgContainerRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        className="relative overflow-auto touch-pan-y"
        style={{ height: 'clamp(360px, 62vh, 760px)', minHeight: '180px', backgroundColor: 'var(--bg-input)' }}
      >
        {loading && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3" style={{ backgroundColor: 'var(--bg-card)' }}>
            <Loader2 size={30} className="animate-spin text-blue-500" />
            <span className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>{progress || 'جاري التحميل...'}</span>
          </div>
        )}

        {pages.length === 0 && !loading && (
          <div className="flex flex-col items-center justify-center py-14 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
            <div className="w-20 h-20 rounded-2xl shadow-sm flex items-center justify-center mb-3" style={{ backgroundColor: 'var(--bg-card-hover)' }}>
              <FileText size={34} style={{ color: 'var(--text-muted)' }} />
            </div>
            <p className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>اضغط لرفع ملف PDF أو صورة</p>
            <p className="text-[11px] mt-1" style={{ color: 'var(--text-muted)' }}>سيتم تحويل الملف إلى صور وعرضها هنا</p>
            <div className="flex items-center gap-3 mt-4">
              <span className="flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"><FileText size={11} />PDF</span>
              <span className="flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400"><ImageIcon size={11} />صور</span>
            </div>
          </div>
        )}

        {pages.length > 0 && (
          <div className="flex items-center justify-center w-full h-full p-3" style={{ transform: `scale(${scale})`, transformOrigin: 'center center', transition: 'transform 0.2s' }}>
            <img
              src={pages[currentPage]}
              alt={`صفحة ${currentPage + 1}`}
              className="w-full h-full rounded-lg shadow-xl select-none object-contain"
              draggable={false}
            />
          </div>
        )}
      </div>

      {/* Mobile bottom navigation */}
      {pages.length > 1 && (
        <div className="flex items-center border-t sm:hidden" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-input)' }}>
          <button onClick={() => goTo(-1)} disabled={currentPage <= 0} className="flex-1 py-3.5 text-center text-sm font-bold disabled:opacity-30 active:bg-[var(--bg-card-hover)] transition-colors" style={{ color: 'var(--text-primary)' }}>
            → السابقة
          </button>
          <div className="flex flex-col items-center px-4">
            <span className="text-xs font-bold" style={{ color: 'var(--text-primary)' }}>{currentPage + 1} / {pages.length}</span>
          </div>
          <button onClick={() => goTo(1)} disabled={currentPage >= pages.length - 1} className="flex-1 py-3.5 text-center text-sm font-bold disabled:opacity-30 active:bg-[var(--bg-card-hover)] transition-colors" style={{ color: 'var(--text-primary)' }}>
            التالية ←
          </button>
        </div>
      )}
    </div>
  );
}
