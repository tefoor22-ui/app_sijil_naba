import { useState, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { Search, Edit3, Trash2, Archive, Eye, X, Filter, Save, Check, Clock, XCircle, CalendarDays, FileText, User, Star } from 'lucide-react';

export default function BeneficiaryList() {
  const { beneficiaries, projects, groups, attendance, activityLog, updateBeneficiary, deleteBeneficiary, archiveBeneficiary, settings, currentProjectId } = useStore();
  const [search, setSearch] = useState('');
  const [filterGroup, setFilterGroup] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>({});
  const [viewingId, setViewingId] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [viewTab, setViewTab] = useState<'info' | 'attendance' | 'log'>('info');

  const filtered = useMemo(() =>
    beneficiaries.filter((b) => {
      if (b.status === 'archived') return false;
      if (currentProjectId && b.projectId !== currentProjectId) return false;
      if (search && !b.name.includes(search) && !b.number.includes(search) && !b.district.includes(search) && !(b.phone || '').includes(search)) return false;
      if (filterGroup && b.groupId !== filterGroup) return false;
      if (filterStatus && b.status !== filterStatus) return false;
      return true;
    }), [beneficiaries, search, filterGroup, filterStatus]);

  const getProjectName = (id: string) => projects.find((p) => p.id === id)?.name || '—';
  const getGroupName = (id: string) => groups.find((g) => g.id === id)?.name || '—';

  const startEdit = (b: any) => { setEditingId(b.id); setEditForm({ ...b }); };
  const saveEdit = () => { if (editingId) { updateBeneficiary(editingId, editForm); setEditingId(null); } };

  const viewing = beneficiaries.find((b) => b.id === viewingId);
  const viewAttendance = useMemo(() => viewing ? attendance.filter((a) => a.beneficiaryId === viewing.id).sort((a, b) => b.date.localeCompare(a.date)) : [], [viewing, attendance]);
  const viewLogs = useMemo(() => viewing ? activityLog.filter((l) => l.beneficiaryId === viewing.id).slice(0, 50) : [], [viewing, activityLog]);

  const statusColors: Record<string, string> = {
    active: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400',
    ended: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
    archived: 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300',
  };
  const statusLabels: Record<string, string> = { active: 'نشط', ended: 'منتهي', archived: 'مؤرشف' };
  const attendanceStats = (bId: string) => {
    const records = attendance.filter((a) => a.beneficiaryId === bId);
    const present = records.filter((a) => a.status === 'present').length;
    return { present, total: records.length, rate: records.length > 0 ? Math.round((present / records.length) * 100) : 0 };
  };

  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };
  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const modalBg = settings.darkMode ? 'rgba(0,0,0,0.7)' : 'rgba(0,0,0,0.5)';

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>سجل المستفيدين</h2>
        <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>عرض وإدارة جميع المستفيدين</p>
      </div>

      {/* Search */}
      <div className="rounded-2xl border p-3 sm:p-4 space-y-3 transition-colors" style={cardStyle}>
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex-1 relative">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث بالاسم أو الرقم أو الحي..."
              className="w-full pr-9 pl-3 py-2.5 border rounded-xl text-sm transition-all focus:outline-none focus:ring-2 focus:ring-blue-500/30" style={inputStyle} />
          </div>
          <button onClick={() => setShowFilters(!showFilters)}
            className={`p-2.5 rounded-xl border transition-colors ${showFilters ? 'bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-800 text-blue-600' : ''}`}
            style={!showFilters ? { borderColor: 'var(--border-color)', color: 'var(--text-secondary)' } : {}}>
            <Filter size={16} />
          </button>
        </div>
        {showFilters && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-3 border-t" style={{ borderColor: 'var(--border-light)' }}>
            <select value={filterGroup} onChange={(e) => setFilterGroup(e.target.value)} className="px-3 py-2 border rounded-xl text-xs" style={inputStyle}>
              <option value="">كل المجموعات</option>
              {groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-2 border rounded-xl text-xs" style={inputStyle}>
              <option value="">كل الحالات</option>
              <option value="active">نشط</option>
              <option value="ended">منتهي</option>
            </select>
          </div>
        )}
      </div>

      <p className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>{filtered.length} مستفيد</p>

      {/* Table */}
      <div className="rounded-2xl border overflow-hidden transition-colors" style={cardStyle}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[800px]">
            <thead>
              <tr style={{ backgroundColor: 'var(--bg-input)' }} className="border-b" >
                {['م','الاسم','الجوال','الرقم','العمر','الحي','المجموعة','الحضور','الحالة','إجراءات'].map((h) => (
                  <th key={h} className="text-right px-3 py-3 text-[11px] font-bold whitespace-nowrap" style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((b, idx) => {
                const stats = attendanceStats(b.id);
                return (
                  <tr key={b.id} className="border-b transition-colors hover:bg-[var(--bg-card-hover)]" style={{ borderColor: 'var(--border-light)' }}>
                    <td className="px-3 py-2.5 text-xs" style={{ color: 'var(--text-muted)' }}>{idx + 1}</td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center shrink-0">
                          <span className="text-white font-bold text-[10px]">{b.name.charAt(0)}</span>
                        </div>
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-sm whitespace-nowrap" style={{ color: 'var(--text-primary)' }}>{b.name}</span>
                            {stats.rate >= 85 && stats.total >= 3 && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-[9px] font-bold rounded-md border border-amber-200/40 dark:border-amber-700/30 shadow-sm shrink-0" title={`طالب متميز - حضر ${stats.present} من ${stats.total} أيام`}>
                                <Star size={10} fill="currentColor" className="shrink-0" />
                                <span>متميز ({stats.present} حضور)</span>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{b.phone || '—'}</td>
                    <td className="px-3 py-2.5 text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{b.number || '—'}</td>
                    <td className="px-3 py-2.5 text-xs" style={{ color: 'var(--text-secondary)' }}>{b.age || '—'}</td>
                    <td className="px-3 py-2.5 text-xs whitespace-nowrap" style={{ color: 'var(--text-secondary)' }}>{b.district || '—'}</td>
                    <td className="px-3 py-2.5 text-[11px] whitespace-nowrap" style={{ color: 'var(--text-muted)' }}>{getGroupName(b.groupId)}</td>
                    <td className="px-3 py-2.5 text-center">
                      {stats.total > 0 ? (
                        <span className={`text-xs font-bold ${stats.rate >= 75 ? 'text-emerald-600 dark:text-emerald-400' : stats.rate >= 50 ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>{stats.rate}%</span>
                      ) : <span className="text-xs" style={{ color: 'var(--text-muted)' }}>—</span>}
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColors[b.status]}`}>{statusLabels[b.status]}</span>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center justify-center gap-0.5">
                        <button onClick={() => { setViewingId(b.id); setViewTab('info'); }} className="p-1.5 rounded-lg transition-colors hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600" style={{ color: 'var(--text-muted)' }}><Eye size={14} /></button>
                        <button onClick={() => startEdit(b)} className="p-1.5 rounded-lg transition-colors hover:bg-amber-50 dark:hover:bg-amber-900/30 hover:text-amber-600" style={{ color: 'var(--text-muted)' }}><Edit3 size={14} /></button>
                        <button onClick={() => archiveBeneficiary(b.id)} className="p-1.5 rounded-lg transition-colors hover:bg-purple-50 dark:hover:bg-purple-900/30 hover:text-purple-600" style={{ color: 'var(--text-muted)' }}><Archive size={14} /></button>
                        <button onClick={() => { if (confirm('حذف؟')) deleteBeneficiary(b.id); }} className="p-1.5 rounded-lg transition-colors hover:bg-red-50 dark:hover:bg-red-900/30 hover:text-red-600" style={{ color: 'var(--text-muted)' }}><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <div className="p-12 text-center text-sm" style={{ color: 'var(--text-muted)' }}>لا يوجد مستفيدين</div>}
      </div>

      {/* Edit Modal */}
      {editingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: modalBg }} onClick={() => setEditingId(null)}>
          <div className="rounded-2xl max-w-lg w-full p-5 max-h-[85vh] overflow-auto animate-fade-in" style={cardStyle} onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>تعديل بيانات المستفيد</h3>
              <button onClick={() => setEditingId(null)} className="p-1.5 rounded-lg hover:bg-[var(--bg-card-hover)]"><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                {[{ key: 'name', label: 'الاسم' }, { key: 'phone', label: 'الجوال', type: 'tel' }, { key: 'number', label: 'الرقم' }, { key: 'age', label: 'العمر', type: 'number' }, { key: 'district', label: 'الحي' }, { key: 'startDate', label: 'البداية', type: 'date' }, { key: 'endDate', label: 'النهاية', type: 'date' }].map((f) => (
                  <div key={f.key}>
                    <label className="block text-[10px] font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>{f.label}</label>
                    <input type={f.type || 'text'} value={editForm[f.key] || ''} onChange={(e) => setEditForm({ ...editForm, [f.key]: e.target.value })}
                      className="w-full px-3 py-2 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30" style={inputStyle} />
                  </div>
                ))}
              </div>
              <div>
                <label className="block text-[10px] font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>المجموعة</label>
                <select value={editForm.groupId || ''} onChange={(e) => setEditForm({ ...editForm, groupId: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl text-sm" style={inputStyle}>
                  <option value="">بدون مجموعة</option>
                  {groups.filter((g) => !currentProjectId || g.projectId === currentProjectId).map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>الحالة</label>
                <select value={editForm.status || ''} onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl text-sm" style={inputStyle}>
                  <option value="active">نشط</option><option value="ended">منتهي</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>ملاحظات</label>
                <textarea value={editForm.notes || ''} onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl text-sm resize-none" rows={2} style={inputStyle} />
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={saveEdit} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl text-sm font-medium active:scale-95">
                  <Save size={15} /> حفظ
                </button>
                <button onClick={() => setEditingId(null)} className="px-5 py-2.5 rounded-xl text-sm" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Modal */}
      {viewing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: modalBg }} onClick={() => setViewingId(null)}>
          <div className="rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col animate-fade-in" style={cardStyle} onClick={(e) => e.stopPropagation()}>
            <div className="p-4 sm:p-5 border-b flex items-center justify-between shrink-0" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold">{viewing.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>{viewing.name}</h3>
                  <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>#{viewing.number} • {getProjectName(viewing.projectId)}</p>
                </div>
              </div>
              <button onClick={() => setViewingId(null)} className="p-1.5 rounded-lg hover:bg-[var(--bg-card-hover)]"><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="flex border-b px-4 sm:px-5 shrink-0" style={{ borderColor: 'var(--border-color)' }}>
              {[{ id: 'info' as const, label: 'البيانات', icon: User }, { id: 'attendance' as const, label: 'الحضور', icon: CalendarDays }, { id: 'log' as const, label: 'التعديلات', icon: FileText }].map((tab) => (
                <button key={tab.id} onClick={() => setViewTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition-colors ${viewTab === tab.id ? 'border-blue-600 text-blue-600' : 'border-transparent'}`}
                  style={viewTab !== tab.id ? { color: 'var(--text-muted)' } : {}}>
                  <tab.icon size={13} />{tab.label}
                </button>
              ))}
            </div>
            <div className="flex-1 overflow-auto p-4 sm:p-5">
              {viewTab === 'info' && (
                <div className="space-y-2">
                  {[['الاسم', viewing.name], ['رقم الجوال', viewing.phone], ['الرقم', viewing.number], ['العمر', viewing.age ? `${viewing.age} سنة` : ''], ['الحي', viewing.district], ['البداية', viewing.startDate], ['النهاية', viewing.endDate], ['المشروع', getProjectName(viewing.projectId)], ['المجموعة', getGroupName(viewing.groupId)], ['الحالة', statusLabels[viewing.status]], ['ملاحظات', viewing.notes]].map(([l, v]) => (
                    <div key={l} className="flex items-center justify-between py-2 border-b" style={{ borderColor: 'var(--border-light)' }}>
                      <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{l}</span>
                      <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{v || '—'}</span>
                    </div>
                  ))}
                  {(() => { const s = attendanceStats(viewing.id); return s.total > 0 ? (
                    <div className="mt-3 p-3 rounded-xl" style={{ backgroundColor: 'var(--bg-input)' }}>
                      <p className="text-xs font-bold mb-2" style={{ color: 'var(--text-secondary)' }}>ملخص الحضور</p>
                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div><p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{s.present}</p><p className="text-[9px]" style={{ color: 'var(--text-muted)' }}>حاضر</p></div>
                        <div><p className="text-lg font-bold text-red-600 dark:text-red-400">{s.total - s.present}</p><p className="text-[9px]" style={{ color: 'var(--text-muted)' }}>غياب/تأخر</p></div>
                        <div><p className={`text-lg font-bold ${s.rate >= 75 ? 'text-emerald-600' : 'text-amber-600'}`}>{s.rate}%</p><p className="text-[9px]" style={{ color: 'var(--text-muted)' }}>النسبة</p></div>
                      </div>
                    </div>
                  ) : null; })()}
                </div>
              )}
              {viewTab === 'attendance' && (
                viewAttendance.length > 0 ? (
                  <div className="overflow-x-auto"><table className="w-full"><thead><tr className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                    <th className="text-right py-2 text-[11px] font-bold" style={{ color: 'var(--text-secondary)' }}>التاريخ</th>
                    <th className="text-center py-2 text-[11px] font-bold" style={{ color: 'var(--text-secondary)' }}>الحالة</th>
                    <th className="text-right py-2 text-[11px] font-bold" style={{ color: 'var(--text-secondary)' }}>المجموعة</th>
                  </tr></thead><tbody>
                    {viewAttendance.map((a) => (
                      <tr key={a.id} className="border-b" style={{ borderColor: 'var(--border-light)' }}>
                        <td className="py-2 text-sm" style={{ color: 'var(--text-primary)' }}>{a.date}</td>
                        <td className="py-2 text-center">
                          {a.status === 'present' && <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-full text-[10px] font-bold"><Check size={10} />حاضر</span>}
                          {a.status === 'absent' && <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 rounded-full text-[10px] font-bold"><XCircle size={10} />غائب</span>}
                          {a.status === 'late' && <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 rounded-full text-[10px] font-bold"><Clock size={10} />متأخر</span>}
                        </td>
                        <td className="py-2 text-xs" style={{ color: 'var(--text-muted)' }}>{getGroupName(a.groupId)}</td>
                      </tr>
                    ))}
                  </tbody></table></div>
                ) : <div className="text-center py-12 text-sm" style={{ color: 'var(--text-muted)' }}>لا يوجد سجل حضور</div>
              )}
              {viewTab === 'log' && (
                viewLogs.length > 0 ? viewLogs.map((l) => (
                  <div key={l.id} className="flex items-start gap-2 py-2 border-b" style={{ borderColor: 'var(--border-light)' }}>
                    <div className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 mt-0.5 ${l.type === 'create' ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600' : l.type === 'update' ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-600' : l.type === 'attendance' ? 'bg-purple-100 dark:bg-purple-900/40 text-purple-600' : 'bg-slate-100 dark:bg-slate-700 text-slate-600'}`}>
                      {l.type === 'create' ? <Check size={10}/> : l.type === 'update' ? <Edit3 size={10}/> : l.type === 'attendance' ? <CalendarDays size={10}/> : <Archive size={10}/>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs" style={{ color: 'var(--text-primary)' }}>{l.action}</p>
                      <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{l.details}</p>
                      {l.field && l.oldValue && <p className="text-[9px] mt-0.5"><span className="bg-red-100 dark:bg-red-900/30 text-red-600 px-1 rounded line-through">{l.oldValue}</span> ← <span className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 px-1 rounded">{l.newValue}</span></p>}
                    </div>
                    <span className="text-[9px] shrink-0" style={{ color: 'var(--text-muted)' }}>{new Date(l.timestamp).toLocaleDateString('ar-SA')}</span>
                  </div>
                )) : <div className="text-center py-12 text-sm" style={{ color: 'var(--text-muted)' }}>لا يوجد سجل</div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
