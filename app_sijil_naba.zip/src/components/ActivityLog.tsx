import { useState, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { ScrollText, Plus, Edit3, Trash2, Archive, Search, Filter, CalendarDays, RotateCcw, ClipboardCheck } from 'lucide-react';

export default function ActivityLog() {
  const { activityLog, beneficiaries } = useStore();
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterBeneficiary, setFilterBeneficiary] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => activityLog.filter((e) => {
    if (search && !e.action.includes(search) && !e.details.includes(search)) return false;
    if (filterType && e.type !== filterType) return false;
    if (filterBeneficiary && e.beneficiaryId !== filterBeneficiary) return false;
    return true;
  }), [activityLog, search, filterType, filterBeneficiary]);

  const typeIcons: Record<string, typeof Plus> = { create: Plus, update: Edit3, delete: Trash2, archive: Archive, attendance: ClipboardCheck, restore: RotateCcw };
  const typeColors: Record<string, string> = { create: 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400', update: 'bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400', delete: 'bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400', archive: 'bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400', attendance: 'bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400', restore: 'bg-cyan-100 dark:bg-cyan-900/40 text-cyan-600 dark:text-cyan-400' };
  const typeLabels: Record<string, string> = { create: 'إنشاء', update: 'تعديل', delete: 'حذف', archive: 'أرشفة', attendance: 'حضور', restore: 'استعادة' };

  const formatDate = (t: string) => {
    const d = new Date(t); const diff = Date.now() - d.getTime(); const m = Math.floor(diff / 60000);
    if (m < 1) return 'الآن'; if (m < 60) return `منذ ${m} د`; const h = Math.floor(diff / 3600000); if (h < 24) return `منذ ${h} س`; const days = Math.floor(diff / 86400000); if (days < 7) return `منذ ${days} يوم`;
    return d.toLocaleDateString('ar-SA');
  };

  const logBeneficiaries = useMemo(() => {
    const ids = new Set(activityLog.filter((l) => l.beneficiaryId).map((l) => l.beneficiaryId!));
    return Array.from(ids).map((id) => beneficiaries.find((b) => b.id === id)).filter(Boolean);
  }, [activityLog, beneficiaries]);

  const groupedByDate = useMemo(() => {
    const map = new Map<string, typeof filtered>();
    filtered.forEach((e) => { const k = new Date(e.timestamp).toLocaleDateString('ar-SA'); if (!map.has(k)) map.set(k, []); map.get(k)!.push(e); });
    return Array.from(map.entries());
  }, [filtered]);

  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>سجل العمليات</h2>
        <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>تتبع جميع العمليات</p>
      </div>

      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {Object.entries(typeLabels).map(([type, label]) => {
          const count = activityLog.filter((l) => l.type === type).length;
          const Icon = typeIcons[type] || ScrollText;
          return (
            <button key={type} onClick={() => setFilterType(filterType === type ? '' : type)}
              className={`rounded-xl p-2.5 text-center border transition-all ${filterType === type ? 'border-blue-300 dark:border-blue-700 shadow-sm' : ''}`}
              style={filterType !== type ? cardStyle : { backgroundColor: 'var(--bg-card)' }}>
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1 ${typeColors[type]}`}><Icon size={12} /></div>
              <p className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>{count}</p>
              <p className="text-[8px] font-medium" style={{ color: 'var(--text-muted)' }}>{label}</p>
            </button>
          );
        })}
      </div>

      <div className="rounded-2xl border p-3 sm:p-4 space-y-3 transition-colors" style={cardStyle}>
        <div className="flex items-center gap-2">
          <div className="flex-1 relative">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث..."
              className="w-full pr-9 pl-3 py-2.5 border rounded-xl text-sm" style={inputStyle} />
          </div>
          <button onClick={() => setShowFilters(!showFilters)} className="p-2.5 rounded-xl border transition-colors" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}><Filter size={15} /></button>
        </div>
        {showFilters && (
          <div className="grid grid-cols-2 gap-2 pt-3 border-t" style={{ borderColor: 'var(--border-light)' }}>
            <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="px-3 py-2 border rounded-xl text-xs" style={inputStyle}>
              <option value="">كل الأنواع</option>{Object.entries(typeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
            <select value={filterBeneficiary} onChange={(e) => setFilterBeneficiary(e.target.value)} className="px-3 py-2 border rounded-xl text-xs" style={inputStyle}>
              <option value="">كل المستفيدين</option>{logBeneficiaries.map((b) => b && <option key={b.id} value={b.id}>{b.name}</option>)}</select>
          </div>
        )}
      </div>

      <p className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>{filtered.length} عملية</p>

      <div className="space-y-5">
        {groupedByDate.map(([date, entries]) => (
          <div key={date}>
            <div className="flex items-center gap-2 mb-2">
              <CalendarDays size={13} style={{ color: 'var(--text-muted)' }} />
              <span className="text-xs font-bold" style={{ color: 'var(--text-secondary)' }}>{date}</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded-full" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-muted)' }}>{entries.length}</span>
            </div>
            <div className="space-y-1.5 border-r-2 pr-4 mr-1.5" style={{ borderColor: 'var(--border-color)' }}>
              {entries.map((entry) => {
                const Icon = typeIcons[entry.type] || ScrollText;
                const ben = entry.beneficiaryId ? beneficiaries.find((b) => b.id === entry.beneficiaryId) : null;
                return (
                  <div key={entry.id} className="rounded-xl border p-3 flex items-start gap-2.5 relative transition-colors" style={cardStyle}>
                    <div className="absolute -right-[21px] top-3.5 w-2.5 h-2.5 rounded-full border-2" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }} />
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${typeColors[entry.type]}`}><Icon size={12} /></div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>{entry.action}</p>
                        <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${typeColors[entry.type]}`}>{typeLabels[entry.type]}</span>
                      </div>
                      <p className="text-[10px] mt-0.5" style={{ color: 'var(--text-muted)' }}>{entry.details}</p>
                      {entry.field && entry.oldValue && <p className="text-[9px] mt-0.5"><span className="bg-red-100 dark:bg-red-900/30 text-red-600 px-1 rounded line-through">{entry.oldValue}</span> ← <span className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 px-1 rounded">{entry.newValue}</span></p>}
                      {ben && <p className="text-[9px] text-blue-500 mt-0.5">{ben.name}</p>}
                    </div>
                    <span className="text-[9px] shrink-0" style={{ color: 'var(--text-muted)' }}>{formatDate(entry.timestamp)}</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="rounded-2xl border p-12 text-center transition-colors" style={cardStyle}>
          <ScrollText size={44} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
          <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>لا توجد عمليات</p>
        </div>
      )}
    </div>
  );
}
