import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Plus, Edit3, Trash2, Layers, X, Save, Palette, Shuffle, SlidersHorizontal } from 'lucide-react';

const GROUP_COLORS = [
  { name: 'أزرق', value: '#3b82f6' },
  { name: 'أخضر', value: '#10b981' },
  { name: 'بنفسجي', value: '#8b5cf6' },
  { name: 'أحمر', value: '#ef4444' },
  { name: 'برتقالي', value: '#f97316' },
  { name: 'وردي', value: '#ec4899' },
  { name: 'سماوي', value: '#06b6d4' },
  { name: 'أصفر', value: '#eab308' },
  { name: 'رمادي', value: '#64748b' },
  { name: 'نيلي', value: '#6366f1' },
];

const emptyGroup = { name: '', projectId: '', description: '', color: '#3b82f6' };

export default function Groups() {
  const { groups, projects, beneficiaries, addGroup, updateGroup, deleteGroup, updateBeneficiary, settings, currentProjectId, distributeStudents } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyGroup });

  const handleSubmit = () => {
    if (!form.name.trim()) return;
    const payload = { ...form, projectId: form.projectId || currentProjectId };
    if (editingId) {
      updateGroup(editingId, payload);
      setEditingId(null);
    } else {
      addGroup(payload);
    }
    setForm({ ...emptyGroup });
    setShowForm(false);
  };

  const startEdit = (g: any) => {
    setEditingId(g.id);
    setForm({ name: g.name, projectId: g.projectId, description: g.description, color: g.color || '#3b82f6' });
    setShowForm(true);
  };

  const getProjectName = (id: string) => projects.find((p) => p.id === id)?.name || '—';
  const visibleGroups = groups.filter((g) => !currentProjectId || g.projectId === currentProjectId);
  const activeStudents = beneficiaries.filter((b) => b.status === 'active' && (!currentProjectId || b.projectId === currentProjectId));
  const ungroupedStudents = activeStudents.filter((b) => !b.groupId);
  const [expandedGroup, setExpandedGroup] = useState<string | null>(null);

  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };
  const modalBg = settings.darkMode ? 'rgba(0,0,0,0.7)' : 'rgba(0,0,0,0.5)';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>المجموعات</h2>
          <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>إدارة مجموعات المستفيدين</p>
        </div>
        <button onClick={() => { setShowForm(true); setEditingId(null); setForm({ ...emptyGroup }); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all active:scale-95">
          <Plus size={17} /> إضافة مجموعة
        </button>
      </div>

      <div className="rounded-2xl border p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3" style={cardStyle}>
        <div>
          <h3 className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>توزيع الطلاب بين المجموعات</h3>
          <p className="text-[11px] mt-1" style={{ color: 'var(--text-muted)' }}>يتم التوزيع بالتساوي بين مجموعات المشروع الحالية. عدد الطلاب: {activeStudents.length}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => distributeStudents('random', currentProjectId)} disabled={visibleGroups.length === 0 || activeStudents.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 text-xs font-bold disabled:opacity-40">
            <Shuffle size={14} /> توزيع عشوائي
          </button>
          <button onClick={() => distributeStudents('age', currentProjectId)} disabled={visibleGroups.length === 0 || activeStudents.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-bold disabled:opacity-40">
            <SlidersHorizontal size={14} /> توزيع حسب العمر
          </button>
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: modalBg }} onClick={() => setShowForm(false)}>
          <div className="rounded-2xl max-w-lg w-full p-5 animate-fade-in" style={cardStyle} onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>{editingId ? 'تعديل مجموعة' : 'إضافة مجموعة جديدة'}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-[var(--bg-card-hover)]">
                <X size={18} style={{ color: 'var(--text-muted)' }} />
              </button>
            </div>
            <div className="space-y-4">
              {/* Name */}
              <div>
                <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  اسم المجموعة <span className="text-red-500">*</span>
                </label>
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                  style={inputStyle}
                  placeholder="مثال: المجموعة الأولى"
                />
              </div>

              {/* Color Picker */}
              <div>
                <label className="flex items-center gap-1.5 text-xs font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>
                  <Palette size={13} /> لون المجموعة
                </label>
                <div className="flex flex-wrap gap-2">
                  {GROUP_COLORS.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => setForm({ ...form, color: c.value })}
                      className={`w-9 h-9 rounded-xl transition-all flex items-center justify-center ${
                        form.color === c.value ? 'ring-2 ring-offset-2 scale-110 shadow-lg' : 'hover:scale-105'
                      }`}
                      style={{
                        backgroundColor: c.value,
                        outlineColor: form.color === c.value ? c.value : undefined,
                      }}
                      title={c.name}
                    >
                      {form.color === c.value && (
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                      )}
                    </button>
                  ))}
                </div>
              </div>



              {/* Description */}
              <div>
                <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>الوصف</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full px-3.5 py-2.5 border rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
                  rows={3}
                  style={inputStyle}
                  placeholder="وصف مختصر للمجموعة (اختياري)"
                />
              </div>

              {/* Preview */}
              {form.name && (
                <div className="rounded-xl p-3 border flex items-center gap-3" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: form.color }}>
                    <Layers size={18} className="text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>{form.name}</p>
                    <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>معاينة المجموعة</p>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <button onClick={handleSubmit}
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl text-sm font-medium active:scale-95 transition-all">
                  <Save size={15} /> {editingId ? 'تحديث' : 'إضافة'}
                </button>
                <button onClick={() => setShowForm(false)}
                  className="px-5 py-2.5 rounded-xl text-sm"
                  style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Groups Grid */}
      <div className="space-y-3">
        {visibleGroups.map((group) => {
          const groupStudents = beneficiaries.filter((b) => b.groupId === group.id && b.status !== 'archived');
          const count = groupStudents.length;
          const color = group.color || '#3b82f6';
          const isExpanded = expandedGroup === group.id;
          return (
            <div key={group.id} className="rounded-2xl border transition-all hover:shadow-md overflow-hidden" style={cardStyle}>
              <div
                className="p-4 sm:p-5 cursor-pointer"
                onClick={() => setExpandedGroup(isExpanded ? null : group.id)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center shadow-sm" style={{ backgroundColor: color }}>
                      <Layers size={20} className="text-white" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>{group.name}</h3>
                      {group.description && <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>{group.description}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={(e) => { e.stopPropagation(); startEdit(group); }} className="p-1.5 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-900/30 transition-colors" style={{ color: 'var(--text-muted)' }}>
                      <Edit3 size={14} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); if (confirm('هل تريد حذف هذه المجموعة؟')) deleteGroup(group.id); }} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30 transition-colors" style={{ color: 'var(--text-muted)' }}>
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{getProjectName(group.projectId)}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg text-white" style={{ backgroundColor: color }}>{count} طالب</span>
                </div>
              </div>

              {/* Student List */}
              {isExpanded && (
                <div className="border-t p-3 space-y-1.5" style={{ borderColor: 'var(--border-light)', backgroundColor: 'var(--bg-input)' }}>
                  {groupStudents.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {groupStudents.map((s, i) => (
                        <div key={s.id} className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs" style={{ backgroundColor: 'var(--bg-card)' }}>
                          <span className="text-[10px] font-bold w-5 h-5 rounded-md flex items-center justify-center shrink-0" style={{ backgroundColor: color, color: 'white' }}>{i + 1}</span>
                          <span className="font-medium truncate" style={{ color: 'var(--text-primary)' }}>{s.name}</span>
                          {s.phone && <span className="text-[9px] shrink-0" style={{ color: 'var(--text-muted)' }}>{s.phone}</span>}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-center py-4" style={{ color: 'var(--text-muted)' }}>لا يوجد طلاب في هذه المجموعة</p>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Ungrouped Students */}
        {ungroupedStudents.length > 0 && (
          <div className="rounded-2xl border border-dashed p-4 sm:p-5" style={{ borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-amber-600 dark:text-amber-400">طلاب بدون مجموعة ({ungroupedStudents.length})</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {ungroupedStudents.map((s) => (
                <div key={s.id} className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-900/10 border border-amber-200/30 dark:border-amber-800/20">
                  <span className="text-xs font-medium truncate" style={{ color: 'var(--text-primary)' }}>{s.name}</span>
                  <select
                    value=""
                    onChange={(e) => { if (e.target.value) updateBeneficiary(s.id, { groupId: e.target.value }, true); }}
                    className="text-[9px] px-1.5 py-1 rounded-md border shrink-0"
                    style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  >
                    <option value="">أضف لمجموعة</option>
                    {visibleGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>
        )}

        {visibleGroups.length === 0 && (
          <div className="rounded-2xl border p-12 text-center transition-colors" style={cardStyle}>
            <Layers size={40} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
            <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>لا توجد مجموعات</p>
            <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>أضف مجموعة جديدة للبدء</p>
          </div>
        )}
      </div>
    </div>
  );
}
