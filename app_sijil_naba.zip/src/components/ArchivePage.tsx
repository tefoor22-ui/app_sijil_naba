import { useState, useMemo, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { RotateCcw, Trash2, Archive, Search, FolderOpen, Filter, AlertCircle } from 'lucide-react';

export default function ArchivePage() {
  const { beneficiaries, projects, groups, deleteBeneficiary, archiveBeneficiary, restoreBeneficiary, autoArchiveCheck, settings, currentProjectId } = useStore();
  const [search, setSearch] = useState('');
  const [filterProject, setFilterProject] = useState('');
  const [filterYear, setFilterYear] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => { autoArchiveCheck(); }, []);

  const archived = useMemo(() => beneficiaries.filter((b) => {
    if (b.status !== 'archived') return false;
    if (currentProjectId && b.projectId !== currentProjectId) return false;
    if (search && !b.name.includes(search) && !b.number.includes(search)) return false;
    if (filterProject && b.projectId !== filterProject) return false;
    if (filterYear) { const y = b.endDate?.substring(0, 4) || ''; if (y !== filterYear) return false; }
    return true;
  }), [beneficiaries, search, filterProject, filterYear]);

  const endedNotArchived = useMemo(() => beneficiaries.filter((b) => b.status === 'ended' && (!currentProjectId || b.projectId === currentProjectId)), [beneficiaries, currentProjectId]);
  const getProjectName = (id: string) => projects.find((p) => p.id === id)?.name || '—';
  const getGroupName = (id: string) => groups.find((g) => g.id === id)?.name || '—';
  const years = useMemo(() => { const s = new Set<string>(); beneficiaries.forEach((b) => { if (b.endDate) s.add(b.endDate.substring(0, 4)); }); return Array.from(s).sort().reverse(); }, [beneficiaries]);

  const groupedByProject = useMemo(() => {
    const map = new Map<string, typeof archived>();
    archived.forEach((b) => { const k = b.projectId || 'none'; if (!map.has(k)) map.set(k, []); map.get(k)!.push(b); });
    return Array.from(map.entries());
  }, [archived]);

  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>الأرشيف</h2>
          <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>أرشفة المستفيدين والمشاريع المنتهية</p>
        </div>
        {settings.autoArchiveEnabled && <span className="text-[10px] bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 px-3 py-1 rounded-full font-bold">✓ أرشفة تلقائية</span>}
      </div>

      {/* Bulk Actions Toolbar */}
      {(beneficiaries.some((b) => b.status === 'active' && (!currentProjectId || b.projectId === currentProjectId)) || archived.length > 0) && (
        <div className="rounded-2xl border p-3 sm:p-4 transition-colors" style={cardStyle}>
          <div className="flex items-center gap-2 mb-3">
            <Archive size={15} className="text-blue-500" />
            <h3 className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>إجراءات جماعية</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => {
                const activeOnes = beneficiaries.filter((b) => b.status === 'active' && (!currentProjectId || b.projectId === currentProjectId));
                if (activeOnes.length === 0) { alert('لا يوجد مستفيدين نشطين للأرشفة'); return; }
                if (confirm(`أرشفة جميع المستفيدين النشطين (${activeOnes.length} مستفيد)؟`)) {
                  activeOnes.forEach((b) => archiveBeneficiary(b.id));
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold active:scale-95 transition-all"
            >
              <Archive size={13} /> أرشفة كل النشطين
            </button>
            <button
              onClick={() => {
                if (archived.length === 0) { alert('لا يوجد مؤرشفون لإعادتهم'); return; }
                if (confirm(`استعادة جميع المؤرشفين (${archived.length} مستفيد)؟`)) {
                  archived.forEach((b) => restoreBeneficiary(b.id));
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold active:scale-95 transition-all"
            >
              <RotateCcw size={13} /> استعادة كل المؤرشفين
            </button>
            <button
              onClick={() => {
                if (archived.length === 0) { alert('الأرشيف فارغ'); return; }
                if (confirm(`⚠️ حذف نهائي لجميع المؤرشفين (${archived.length})؟ لا يمكن التراجع.`)) {
                  archived.forEach((b) => deleteBeneficiary(b.id));
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/50 border border-red-200/50 dark:border-red-800/30 rounded-xl text-xs font-bold active:scale-95 transition-all mr-auto"
            >
              <Trash2 size={13} /> حذف الأرشيف نهائياً
            </button>
          </div>
        </div>
      )}

      {endedNotArchived.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-3"><AlertCircle size={16} className="text-amber-600 dark:text-amber-400" /><h3 className="font-bold text-amber-800 dark:text-amber-300 text-sm">{endedNotArchived.length} مستفيد جاهز للأرشفة</h3></div>
          <div className="space-y-1.5">
            {endedNotArchived.slice(0, 4).map((b) => (
              <div key={b.id} className="flex items-center justify-between rounded-lg px-3 py-2" style={{ backgroundColor: 'var(--bg-card)' }}>
                <span className="text-sm" style={{ color: 'var(--text-primary)' }}>{b.name}</span>
                <button onClick={() => archiveBeneficiary(b.id)} className="text-[10px] font-bold text-amber-600 dark:text-amber-400 hover:underline">أرشفة</button>
              </div>
            ))}
            {endedNotArchived.length > 4 && <p className="text-[10px] text-center" style={{ color: 'var(--text-muted)' }}>و {endedNotArchived.length - 4} آخرين</p>}
            <button onClick={() => endedNotArchived.forEach((b) => archiveBeneficiary(b.id))} className="w-full mt-2 py-2 bg-amber-600 text-white rounded-xl text-xs font-bold hover:bg-amber-700 active:scale-95 transition-all">أرشفة الكل</button>
          </div>
        </div>
      )}

      <div className="rounded-2xl border p-3 sm:p-4 space-y-3 transition-colors" style={cardStyle}>
        <div className="flex items-center gap-2">
          <div className="flex-1 relative">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث في الأرشيف..."
              className="w-full pr-9 pl-3 py-2.5 border rounded-xl text-sm" style={inputStyle} />
          </div>
          <button onClick={() => setShowFilters(!showFilters)} className="p-2.5 rounded-xl border transition-colors" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}><Filter size={15} /></button>
        </div>
        {showFilters && (
          <div className="grid grid-cols-2 gap-2 pt-3 border-t" style={{ borderColor: 'var(--border-light)' }}>
            <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)} className="px-3 py-2 border rounded-xl text-xs" style={inputStyle}>
              <option value="">كل المشاريع</option>{projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
            <select value={filterYear} onChange={(e) => setFilterYear(e.target.value)} className="px-3 py-2 border rounded-xl text-xs" style={inputStyle}>
              <option value="">كل السنوات</option>{years.map((y) => <option key={y} value={y}>{y}</option>)}</select>
          </div>
        )}
      </div>

      <p className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>{archived.length} مؤرشف</p>

      {groupedByProject.map(([pid, items]) => (
        <div key={pid} className="space-y-2">
          <div className="flex items-center gap-2 py-1">
            <FolderOpen size={14} className="text-blue-500" />
            <h3 className="font-bold text-sm" style={{ color: 'var(--text-secondary)' }}>{pid === 'none' ? 'بدون مشروع' : getProjectName(pid)}</h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-muted)' }}>{items.length}</span>
          </div>
          {items.map((b) => (
            <div key={b.id} className="rounded-xl border p-3 sm:p-4 transition-colors" style={cardStyle}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--bg-input)' }}><Archive size={16} style={{ color: 'var(--text-muted)' }} /></div>
                  <div>
                    <p className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>{b.name}</p>
                    <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>#{b.number} • {getGroupName(b.groupId)} • {b.endDate || '—'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button onClick={() => restoreBeneficiary(b.id)} className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 rounded-lg text-[10px] font-bold hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors"><RotateCcw size={11} /> استعادة</button>
                  <button onClick={() => { if (confirm('حذف نهائي؟')) deleteBeneficiary(b.id); }} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30 transition-colors" style={{ color: 'var(--text-muted)' }}><Trash2 size={14} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ))}

      {archived.length === 0 && (
        <div className="rounded-2xl border p-12 text-center transition-colors" style={cardStyle}>
          <Archive size={44} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
          <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>لا يوجد عناصر مؤرشفة</p>
        </div>
      )}
    </div>
  );
}
