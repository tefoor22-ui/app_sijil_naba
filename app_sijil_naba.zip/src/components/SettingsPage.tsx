import { useStore } from '../store/useStore';
import { Settings, Trash2, Download, Upload, Shield, Clock, Archive, HardDrive, RefreshCw, FileDown, Info, Moon, Sun, FileSpreadsheet } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import AppleToggle from './AppleToggle';

let xlsxLoaded = false;
let xlsxLib: any = null;

async function loadXlsxJs(): Promise<any> {
  if (xlsxLoaded && xlsxLib) return xlsxLib;
  return new Promise((resolve, reject) => {
    if ((window as any).XLSX) {
      xlsxLib = (window as any).XLSX;
      xlsxLoaded = true;
      resolve(xlsxLib);
      return;
    }
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
    s.onload = () => {
      xlsxLib = (window as any).XLSX;
      xlsxLoaded = true;
      resolve(xlsxLib);
    };
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

export default function SettingsPage() {
  const { settings, updateSettings, toggleDarkMode, beneficiaries, projects, groups, attendance, activityLog, backups, createBackup, restoreBackup, deleteBackup } = useStore();
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState<string | null>(null);
  const [backupCreated, setBackupCreated] = useState(false);
  const autoBackupTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (settings.autoBackupEnabled) {
      const check = () => {
        if (!settings.lastBackup) { createBackup(); return; }
        const diff = Date.now() - new Date(settings.lastBackup).getTime();
        if (diff >= settings.autoBackupInterval * 3600000) createBackup();
      };
      check();
      autoBackupTimerRef.current = setInterval(check, 3600000);
      return () => { if (autoBackupTimerRef.current) clearInterval(autoBackupTimerRef.current); };
    }
  }, [settings.autoBackupEnabled, settings.autoBackupInterval]);

  const handleManualBackup = () => { createBackup(); setBackupCreated(true); setTimeout(() => setBackupCreated(false), 3000); };

  const exportData = () => {
    const blob = new Blob([JSON.stringify({ beneficiaries, projects, groups, attendance, activityLog, settings, exportDate: new Date().toISOString(), version: '3.0' }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `نسخة_احتياطية_${new Date().toISOString().split('T')[0]}.json`; a.click();
  };

  const importExcelData = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const XLSX = await loadXlsxJs();
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const arrayBuffer = event.target?.result as ArrayBuffer;
          const data = new Uint8Array(arrayBuffer);
          const wb = XLSX.read(data, { type: 'array' });
          const ws = wb.Sheets[wb.SheetNames[0]];

          // Read RAW rows (no auto-header) to scan for the actual header row
          const rawRows: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' }) as any[][];
          if (!rawRows || rawRows.length === 0) return alert('الملف فارغ');

          const { currentProjectId, addLog } = useStore.getState();
          const today = new Date().toISOString().split('T')[0];

          // Normalize Arabic text: strip diacritics, unify alef/yeh/teh-marbuta, collapse spaces
          const normalize = (s: any) =>
            String(s ?? '')
              .replace(/[\u064B-\u065F\u0670]/g, '') // diacritics
              .replace(/[إأآا]/g, 'ا')
              .replace(/ى/g, 'ي')
              .replace(/ة/g, 'ه')
              .replace(/[ـ]/g, '')
              .replace(/\s+/g, ' ')
              .trim()
              .toLowerCase();

          // Field aliases used both for header detection and pickField
          const FIELD_ALIASES: Record<string, string[]> = {
            name: ['الاسم الكامل', 'اسم الطالب', 'الاسم', 'اسم كامل', 'اسم', 'name', 'full name', 'student name'],
            phone: ['رقم الجوال', 'رقم الهاتف', 'رقم التواصل', 'الجوال', 'الهاتف', 'جوال', 'هاتف', 'موبايل', 'الموبايل', 'phone', 'mobile', 'phone number', 'contact', 'tel', 'telephone'],
            number: ['رقم المستفيد', 'الرقم', 'الرقم التسلسلي', 'رقم الطالب', 'number', 'id', 'student id'],
            age: ['العمر', 'عمر الطالب', 'السن', 'عمر', 'سن', 'age'],
            district: ['الحي', 'الحي السكني', 'حي السكني', 'في اي حي تسكن', 'في أي حي تسكن', 'حي', 'المنطقة', 'العنوان', 'district', 'neighborhood', 'address', 'area'],
            startDate: ['تاريخ البداية', 'تاريخ التسجيل', 'البداية', 'start date', 'startdate'],
            endDate: ['تاريخ النهاية', 'تاريخ التخرج', 'النهاية', 'end date', 'enddate'],
            notes: ['ملاحظات', 'الملاحظات', 'ملاحظة', 'notes', 'note', 'remarks'],
          };

          // Check if a single cell text matches any of the alias keywords for any known field
          const cellMatchesAnyField = (cell: any): boolean => {
            const n = normalize(cell);
            if (!n) return false;
            for (const aliases of Object.values(FIELD_ALIASES)) {
              for (const alias of aliases) {
                const na = normalize(alias);
                if (n === na || n.includes(na) || na.includes(n)) return true;
              }
            }
            return false;
          };

          // Smart header detection: scan first 15 rows and pick the row with the most field matches
          let headerRowIndex = 0;
          let bestScore = 0;
          const scanLimit = Math.min(15, rawRows.length);
          for (let i = 0; i < scanLimit; i++) {
            const row = rawRows[i] || [];
            let score = 0;
            for (const cell of row) {
              if (cellMatchesAnyField(cell)) score++;
            }
            if (score > bestScore) {
              bestScore = score;
              headerRowIndex = i;
            }
          }

          // Need at least 1 recognized header column to consider it valid
          if (bestScore === 0) {
            return alert('لم يتم التعرف على عمود الاسم في الملف.\nتأكد أن الملف يحتوي على عمود بعنوان "الاسم" أو "اسم الطالب" أو "الاسم الكامل"');
          }

          const headerRow: any[] = rawRows[headerRowIndex] || [];
          const dataStartIndex = headerRowIndex + 1;

          // Build array of objects {headerName: cellValue} starting from data rows
          const json: any[] = [];
          for (let r = dataStartIndex; r < rawRows.length; r++) {
            const row = rawRows[r] || [];
            // Skip fully-empty rows
            const hasAny = row.some((c) => String(c ?? '').trim() !== '');
            if (!hasAny) continue;
            const obj: any = {};
            headerRow.forEach((h, idx) => {
              if (h !== undefined && h !== null && String(h).trim() !== '') {
                obj[String(h).trim()] = row[idx];
              }
            });
            json.push(obj);
          }

          if (json.length === 0) return alert('الملف لا يحتوي على بيانات طلاب');

          // Find a value in the row by trying multiple alias keywords (substring match)
          const pickField = (row: any, aliases: string[]): string => {
            const keys = Object.keys(row);
            const normalizedAliases = aliases.map(normalize);
            for (const key of keys) {
              const nKey = normalize(key);
              for (const alias of normalizedAliases) {
                if (nKey === alias || nKey.includes(alias) || alias.includes(nKey)) {
                  return String(row[key] ?? '').trim();
                }
              }
            }
            return '';
          };

          // Normalize a phone number: strip non-digits, keep leading zero, ensure Saudi format
          const normalizePhone = (raw: string): string => {
            if (!raw) return '';
            // Convert to string and strip everything except digits
            let digits = String(raw).replace(/[^\d]/g, '');
            // If Excel removed the leading zero (number became 9 digits starting with 5), restore it
            if (digits.length === 9 && digits.startsWith('5')) digits = '0' + digits;
            // Strip Saudi country code if present
            if (digits.startsWith('966') && digits.length === 12) digits = '0' + digits.substring(3);
            if (digits.startsWith('00966') && digits.length === 14) digits = '0' + digits.substring(5);
            return digits;
          };

          // Normalize age: keep digits only
          const normalizeAge = (raw: string): string => {
            if (!raw) return '';
            const digits = String(raw).replace(/[^\d]/g, '');
            return digits;
          };

          const newStudents = json.map((row) => {
            const name = pickField(row, [
              'الاسم الكامل', 'اسم الطالب', 'الاسم', 'اسم كامل', 'اسم',
              'name', 'full name', 'student name',
            ]);
            const phoneRaw = pickField(row, [
              'رقم الجوال', 'رقم الهاتف', 'رقم التواصل', 'الجوال', 'الهاتف', 'جوال', 'هاتف', 'موبايل', 'الموبايل',
              'phone', 'mobile', 'phone number', 'contact', 'tel', 'telephone',
            ]);
            const phone = normalizePhone(phoneRaw);
            const number = pickField(row, [
              'رقم المستفيد', 'الرقم', 'الرقم التسلسلي', 'رقم الطالب',
              'number', 'id', 'student id',
            ]);
            const age = normalizeAge(pickField(row, [
              'العمر', 'عمر الطالب', 'السن', 'عمر', 'سن',
              'age',
            ]));
            const district = pickField(row, [
              'الحي', 'الحي السكني', 'حي السكني', 'في اي حي تسكن', 'في أي حي تسكن', 'حي',
              'المنطقة', 'العنوان',
              'district', 'neighborhood', 'address', 'area',
            ]);
            const startDate = pickField(row, [
              'تاريخ البداية', 'تاريخ التسجيل', 'البداية',
              'start date', 'startdate',
            ]) || today;
            const endDate = pickField(row, [
              'تاريخ النهاية', 'تاريخ التخرج', 'النهاية',
              'end date', 'enddate',
            ]);
            const notes = pickField(row, [
              'ملاحظات', 'الملاحظات', 'ملاحظة',
              'notes', 'note', 'remarks',
            ]);

            return {
              id: Math.random().toString(36).substring(2, 11) + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
              name, phone, number, age, district, startDate, endDate, notes,
              projectId: currentProjectId,
              groupId: '',
              status: 'active' as const,
              createdAt: new Date().toISOString(),
            };
          }).filter(b => b.name);

          if (newStudents.length === 0) {
            return alert('لم يتم العثور على طلاب! تأكد من وجود عمود بعنوان "الاسم" أو "اسم الطالب"');
          }

          // Add students through the store and save immediately
          useStore.setState((s) => ({
            beneficiaries: [...s.beneficiaries, ...newStudents]
          }));

          // Persist to localStorage immediately
          const updated = useStore.getState();
          try {
            localStorage.setItem('beneficiary-system-data', JSON.stringify({
              beneficiaries: updated.beneficiaries,
              projects: updated.projects,
              groups: updated.groups,
              attendance: updated.attendance,
              activityLog: updated.activityLog,
              settings: updated.settings,
            }));
          } catch (storageErr) {
            console.error('Storage error:', storageErr);
          }

          // Build a summary
          const withPhone = newStudents.filter(s => s.phone).length;
          const withAge = newStudents.filter(s => s.age).length;
          const withDistrict = newStudents.filter(s => s.district).length;

          addLog('استيراد طلاب من إكسل', `تم استيراد ${newStudents.length} طلاب من ملف إكسل للمشروع الحالي`, 'create');
          alert(
            `✓ تم استيراد ${newStudents.length} طالب بنجاح\n\n` +
            `• مع رقم جوال: ${withPhone}\n` +
            `• مع العمر: ${withAge}\n` +
            `• مع الحي: ${withDistrict}`
          );
        } catch { alert('خطأ في معالجة الملف'); }
      };
      reader.readAsArrayBuffer(file);
    } catch { alert('فشل تحميل أداة الإكسل'); }
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { try { const d = JSON.parse(reader.result as string); if (d.beneficiaries) { localStorage.setItem('beneficiary-system-data', JSON.stringify(d)); window.location.reload(); } else alert('ملف غير صالح'); } catch { alert('ملف غير صالح'); } };
    reader.readAsText(file);
  };

  const resetData = () => {
    // Clear data but stay inside the current project — no reload, no kick to welcome screen.
    // Wipes: students, attendance, activity log, backups, drafts. Keeps: projects, groups, settings.
    try {
      localStorage.removeItem('beneficiary-system-backups');
      localStorage.removeItem('beneficiary-draft');
    } catch {}

    useStore.setState({
      beneficiaries: [],
      attendance: [],
      activityLog: [],
      backups: [],
      undoStack: [],
      // Keep projects, groups, settings, currentProjectId untouched
    });

    // Persist the cleared state
    const updated = useStore.getState();
    try {
      localStorage.setItem('beneficiary-system-data', JSON.stringify({
        beneficiaries: updated.beneficiaries,
        projects: updated.projects,
        groups: updated.groups,
        attendance: updated.attendance,
        activityLog: updated.activityLog,
        settings: updated.settings,
      }));
    } catch {}

    setShowConfirmReset(false);
  };
  const downloadBackup = (b: typeof backups[0]) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([b.data], { type: 'application/json' })); a.download = `نسخة_${new Date(b.date).toISOString().split('T')[0]}.json`; a.click(); };
  const formatSize = (bytes: number) => bytes < 1024 ? `${bytes} B` : bytes < 1048576 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / 1048576).toFixed(1)} MB`;
  const formatDate = (d: string) => new Date(d).toLocaleDateString('ar-SA') + ' — ' + new Date(d).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });

  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };
  const modalBg = settings.darkMode ? 'rgba(0,0,0,0.7)' : 'rgba(0,0,0,0.5)';

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>الإعدادات</h2>
        <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>إعدادات النظام والنسخ الاحتياطي</p>
      </div>

      {/* About App */}
      <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
        <div className="flex items-center gap-3 mb-4">
          <img src="/logo.png" alt="سِجلّ" className="w-14 h-14 rounded-[16px] shadow-lg" draggable={false} />
          <div>
            <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>تطبيق سِجلّ</h3>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>الإصدار 3.0.0</p>
          </div>
        </div>
        <div className="rounded-xl p-4 space-y-2" style={{ backgroundColor: 'var(--bg-input)' }}>
          <div className="flex items-start gap-2">
            <Info size={16} className="text-blue-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>حول التطبيق</p>
              <p className="text-xs mt-1 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                تم انشاء وتطوير هذا التطبيق (سِجلّ) خصيصاً لمؤسسة نبع للترفيه لتسهيل عمل الباذلين في إدارة الطلاب والمستفيدين داخل المشاريع المختلفة. يوفر النظام أدوات متكاملة لتنظيم العمل، تقليل الوقت، وتحسين دقة البيانات مع واجهة بسيطة وسريعة.
              </p>
              <div className="mt-3 rounded-xl p-3 border" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
                <p className="text-xs font-semibold" style={{ color: 'var(--text-primary)' }}>طريقة عرض الصور أثناء الإدخال</p>
                <p className="text-[11px] mt-1 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  في اللابتوب والآيباد بالعرض يتم عرض صورة الملف بجانب نموذج الإدخال حتى تستطيع مراجعة الصورة وكتابة البيانات في نفس الوقت. في الجوال أو الآيباد بالوضع العمودي تظهر الصورة في الأعلى والنموذج أسفلها لتسهيل استخدام الكيبورد بدون تغطية الحقول.
                </p>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 pt-2">
            {['إدارة مستفيدين', 'حضور وغياب', 'تقارير متقدمة', 'نسخ احتياطي', 'أرشفة تلقائية'].map((f) => (
              <span key={f} className="px-2 py-1 rounded-lg text-[10px] font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">{f}</span>
            ))}
          </div>
        </div>

        {/* Credits — Authors only */}
        <div className="mt-4 pt-3 border-t text-center" style={{ borderColor: 'var(--border-light)' }}>
          <p className="text-[11px] leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            تم إنشاء هذا التطبيق بواسطة عبدالله اليحيى وعبدالحكيم العتيبي وبدر المطيري
          </p>
          <p className="text-[10px] mt-1 font-medium" style={{ color: 'var(--text-muted)' }}>
            مدة التطوير: 7 أشهر متواصلة
          </p>
        </div>
      </div>

      {/* Appearance */}
      <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
        <h3 className="text-base font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
          {settings.darkMode ? <Moon size={18} className="text-blue-400" /> : <Sun size={18} className="text-amber-500" />}
          المظهر
        </h3>
        <div className="flex items-center justify-between py-3">
          <div>
            <p className="font-medium text-sm" style={{ color: 'var(--text-primary)' }}>الوضع الليلي</p>
            <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>تبديل بين الوضع الفاتح والليلي</p>
          </div>
          <AppleToggle checked={settings.darkMode} onChange={toggleDarkMode} />
        </div>
      </div>

      {/* General */}
      <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
        <h3 className="text-base font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
          <Settings size={18} className="text-blue-500" /> إعدادات عامة
        </h3>
        {[
          { label: 'الحفظ التلقائي', desc: 'حفظ المسودة تلقائياً', value: settings.autoSave, toggle: () => updateSettings({ autoSave: !settings.autoSave }) },
          { label: 'الأرشفة التلقائية', desc: 'أرشفة المنتهين تلقائياً', value: settings.autoArchiveEnabled, toggle: () => updateSettings({ autoArchiveEnabled: !settings.autoArchiveEnabled }) },
        ].map((item) => (
          <div key={item.label} className="flex items-center justify-between py-3 border-b last:border-0" style={{ borderColor: 'var(--border-light)' }}>
            <div>
              <p className="font-medium text-sm" style={{ color: 'var(--text-primary)' }}>{item.label}</p>
              <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>{item.desc}</p>
            </div>
            <AppleToggle checked={item.value} onChange={item.toggle} />
          </div>
        ))}
      </div>

      {/* Backup */}
      <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
        <h3 className="text-base font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
          <Shield size={18} className="text-emerald-500" /> النسخ الاحتياطي
        </h3>
        <div className="flex items-center justify-between py-3 border-b" style={{ borderColor: 'var(--border-light)' }}>
          <div>
            <p className="font-medium text-sm" style={{ color: 'var(--text-primary)' }}>نسخ تلقائي</p>
            <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>إنشاء نسخة دورياً</p>
          </div>
          <AppleToggle checked={settings.autoBackupEnabled} onChange={() => updateSettings({ autoBackupEnabled: !settings.autoBackupEnabled })} />
        </div>
        {settings.autoBackupEnabled && (
          <div className="flex items-center justify-between py-3 border-b" style={{ borderColor: 'var(--border-light)' }}>
            <p className="text-sm" style={{ color: 'var(--text-primary)' }}>الفترة</p>
            <select value={settings.autoBackupInterval} onChange={(e) => updateSettings({ autoBackupInterval: Number(e.target.value) })}
              className="px-3 py-1.5 border rounded-lg text-xs" style={inputStyle}>
              <option value={6}>كل 6 ساعات</option><option value={12}>12 ساعة</option><option value={24}>24 ساعة</option><option value={48}>48 ساعة</option>
            </select>
          </div>
        )}
        {settings.lastBackup && <p className="flex items-center gap-1.5 py-2 text-[11px]" style={{ color: 'var(--text-muted)' }}><Clock size={12} /> آخر نسخة: {formatDate(settings.lastBackup)}</p>}
        <button onClick={handleManualBackup} className="mt-3 flex items-center gap-2 px-4 py-2.5 bg-gradient-to-l from-emerald-500 to-emerald-600 text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all active:scale-95">
          <RefreshCw size={15} /> إنشاء نسخة الآن
        </button>
        {backupCreated && <p className="text-xs text-emerald-500 mt-2">✓ تم بنجاح</p>}
      </div>

      {/* Backup History */}
      {backups.length > 0 && (
        <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
          <h3 className="text-base font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
            <HardDrive size={18} className="text-blue-500" /> النسخ المحفوظة <span className="text-[10px] font-normal px-2 py-0.5 rounded-full" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-muted)' }}>{backups.length}/10</span>
          </h3>
          <div className="space-y-2">
            {backups.map((b, i) => (
              <div key={b.id} className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: 'var(--bg-input)' }}>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center"><Archive size={14} className="text-blue-600 dark:text-blue-400" /></div>
                  <div>
                    <p className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>نسخة #{backups.length - i}</p>
                    <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{formatDate(b.date)} • {formatSize(b.size)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => downloadBackup(b)} className="p-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/30" style={{ color: 'var(--text-muted)' }}><FileDown size={14} /></button>
                  <button onClick={() => setShowRestoreConfirm(b.id)} className="px-2 py-1 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 rounded-lg text-[10px] font-bold">استعادة</button>
                  <button onClick={() => deleteBackup(b.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30" style={{ color: 'var(--text-muted)' }}><Trash2 size={13} /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Data Management */}
      <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
        <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text-primary)' }}>إدارة البيانات</h3>
        <div className="space-y-2">
          <button onClick={exportData} className="w-full flex items-center gap-3 px-4 py-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors text-right">
            <Download size={17} /><div><p className="font-medium text-sm">تصدير البيانات</p><p className="text-[10px] opacity-70">تنزيل نسخة JSON</p></div>
          </button>
          <label className="w-full flex items-center gap-3 px-4 py-3 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors cursor-pointer text-right">
            <Upload size={17} /><div><p className="font-medium text-sm">استيراد البيانات</p><p className="text-[10px] opacity-70">استعادة من JSON</p></div>
            <input type="file" accept=".json" onChange={importData} className="hidden" />
          </label>
          <label className="w-full flex items-center gap-3 px-4 py-3 bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-400 rounded-xl hover:bg-teal-100 dark:hover:bg-teal-900/30 transition-colors cursor-pointer text-right">
            <FileSpreadsheet size={17} /><div><p className="font-medium text-sm">استيراد طلاب من Excel</p><p className="text-[10px] opacity-70">إضافة طلاب من ملف إكسل للمشروع الحالي</p></div>
            <input type="file" accept=".xlsx, .xls" onChange={importExcelData} className="hidden" />
          </label>
          <button onClick={() => setShowConfirmReset(true)} className="w-full flex items-center gap-3 px-4 py-3 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 rounded-xl hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors text-right">
            <Trash2 size={17} /><div><p className="font-medium text-sm">مسح جميع البيانات</p><p className="text-[10px] opacity-70">حذف نهائي</p></div>
          </button>
        </div>
      </div>

      {/* Storage */}
      <div className="rounded-2xl border p-5 transition-colors" style={cardStyle}>
        <h3 className="text-base font-bold mb-3" style={{ color: 'var(--text-primary)' }}>التخزين</h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {[{ l: 'مستفيد', v: beneficiaries.length, c: 'text-blue-600' }, { l: 'مشروع', v: projects.length, c: 'text-emerald-600' }, { l: 'مجموعة', v: groups.length, c: 'text-purple-600' }, { l: 'حضور', v: attendance.length, c: 'text-amber-600' }, { l: 'عملية', v: activityLog.length, c: 'text-red-600' }].map((i) => (
            <div key={i.l} className="rounded-xl p-3 text-center" style={{ backgroundColor: 'var(--bg-input)' }}>
              <p className={`text-xl font-bold ${i.c}`}>{i.v}</p>
              <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{i.l}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Modals */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: modalBg }} onClick={() => setShowConfirmReset(false)}>
          <div className="rounded-2xl max-w-sm w-full p-6 text-center animate-fade-in" style={cardStyle} onClick={(e) => e.stopPropagation()}>
            <div className="w-14 h-14 bg-red-100 dark:bg-red-900/30 rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4"><Trash2 size={24} className="text-red-600" /></div>
            <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>تأكيد مسح البيانات</h3>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>سيتم حذف كل شيء نهائياً</p>
            <div className="flex gap-3">
              <button onClick={resetData} className="flex-1 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium">نعم، احذف</button>
              <button onClick={() => setShowConfirmReset(false)} className="flex-1 py-2.5 rounded-xl text-sm" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>إلغاء</button>
            </div>
          </div>
        </div>
      )}
      {showRestoreConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: modalBg }} onClick={() => setShowRestoreConfirm(null)}>
          <div className="rounded-2xl max-w-sm w-full p-6 text-center animate-fade-in" style={cardStyle} onClick={(e) => e.stopPropagation()}>
            <div className="w-14 h-14 bg-amber-100 dark:bg-amber-900/30 rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4"><RefreshCw size={24} className="text-amber-600" /></div>
            <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>استعادة النسخة</h3>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>سيتم استبدال البيانات الحالية</p>
            <div className="flex gap-3">
              <button onClick={() => { restoreBackup(showRestoreConfirm); setShowRestoreConfirm(null); }} className="flex-1 py-2.5 bg-amber-600 text-white rounded-xl text-sm font-medium">استعادة</button>
              <button onClick={() => setShowRestoreConfirm(null)} className="flex-1 py-2.5 rounded-xl text-sm" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
