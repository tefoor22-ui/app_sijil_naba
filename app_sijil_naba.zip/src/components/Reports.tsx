import { useState } from 'react';
import { useStore } from '../store/useStore';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import { FileSpreadsheet, FileText, Calendar, FolderOpen, Loader2 } from 'lucide-react';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

export default function Reports() {
  const { beneficiaries, projects, groups, attendance, currentProjectId } = useStore();
  const [reportType, setReportType] = useState<'daily' | 'project' | 'overview'>('overview');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [exporting, setExporting] = useState('');
  const [exportResult, setExportResult] = useState<{
    type: 'excel' | 'pdf' | 'daily';
    fileName: string;
    blob: Blob;
    blobUrl: string;
    htmlContent: string;
  } | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  const getGroupName = (id: string) => groups.find((g) => g.id === id)?.name || '—';

  const projectBen = beneficiaries.filter((b) => !currentProjectId || b.projectId === currentProjectId);
  const projectGroups = groups.filter((g) => !currentProjectId || g.projectId === currentProjectId);

  const projectData = projectGroups.map((g) => ({
    name: g.name.length > 18 ? g.name.substring(0, 18) + '…' : g.name,
    active: projectBen.filter((b) => b.groupId === g.id && b.status === 'active').length,
    ended: projectBen.filter((b) => b.groupId === g.id && b.status !== 'active').length,
  }));

  const statusData = [
    { name: 'نشط', value: beneficiaries.filter((b) => b.status === 'active').length },
    { name: 'منتهي', value: beneficiaries.filter((b) => b.status === 'ended').length },
    { name: 'مؤرشف', value: beneficiaries.filter((b) => b.status === 'archived').length },
  ].filter((d) => d.value > 0);

  const ageRanges = [
    { range: '5–7 سنوات', min: 5, max: 7 },
    { range: '8–10 سنوات', min: 8, max: 10 },
    { range: '11–13 سنة', min: 11, max: 13 },
    { range: '14–16 سنة', min: 14, max: 16 },
    { range: '17–18 سنة', min: 17, max: 18 },
  ];
  const ageData = ageRanges.map((r) => ({
    name: r.range,
    value: beneficiaries.filter((b) => {
      const age = parseInt(b.age);
      return !isNaN(age) && age >= r.min && age <= r.max;
    }).length,
  }));

  const attendanceData = groups.map((g) => {
    const ga = attendance.filter((a) => a.groupId === g.id);
    const present = ga.filter((a) => a.status === 'present').length;
    const total = ga.length;
    return { name: g.name, rate: total > 0 ? Math.round((present / total) * 100) : 0 };
  });

  const dailyAttendance = attendance.filter((a) => a.date === selectedDate);
  const dailyPresent = dailyAttendance.filter((a) => a.status === 'present').length;
  const dailyAbsent = dailyAttendance.filter((a) => a.status === 'absent').length;
  const dailyLate = dailyAttendance.filter((a) => a.status === 'late').length;

  const projectBeneficiaries = projectBen;



  const buildReportHTML = (forExcel = false) => {
    const projectName = currentProjectId ? projects.find((p) => p.id === currentProjectId)?.name || '' : '';
    const todayStr = new Date().toLocaleDateString('ar-SA');
    const numActive = projectBen.filter(b => b.status === 'active').length;

    const excelMeta = forExcel ? `<!--[if gte mso 9]><xml>
<x:ExcelWorkbook xmlns:x="urn:schemas-microsoft-com:office:excel">
<x:ExcelWorksheets><x:ExcelWorksheet><x:Name>التقرير</x:Name>
<x:WorksheetOptions><x:DisplayRightToLeft/></x:WorksheetOptions>
</x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->` : '';

    return `<html dir="rtl" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8">${excelMeta}
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,Tahoma,sans-serif;direction:rtl;text-align:right;color:#1e293b;padding:${forExcel ? '0' : '24px'}}

/* ===== HEADER BANNER ===== */
.banner{background:linear-gradient(135deg,#064e3b 0%,#047857 50%,#059669 100%);padding:${forExcel ? '16px 20px' : '24px 32px'};color:#fff;${forExcel ? '' : 'border-radius:12px;'}margin-bottom:${forExcel ? '0' : '20px'}}
.banner h1{font-size:${forExcel ? '18pt' : '22pt'};font-weight:bold;margin:0 0 2px 0;letter-spacing:-0.3px}
.banner .sub{font-size:10pt;opacity:0.8;margin:0}

/* ===== INFO CARDS ===== */
.cards{${forExcel ? '' : 'display:flex;gap:0;'}width:100%;margin-bottom:${forExcel ? '4px' : '20px'};border:1px solid #d1fae5;${forExcel ? '' : 'border-radius:10px;'}overflow:hidden}
.card{${forExcel ? 'display:inline-block;width:33%;' : 'flex:1;'}text-align:center;padding:${forExcel ? '10px 6px' : '14px 12px'};border-left:1px solid #d1fae5}
.card:last-child{border-left:none}
.card-label{font-size:9pt;color:#047857;font-weight:bold;margin-bottom:3px}
.card-value{font-size:${forExcel ? '13pt' : '16pt'};color:#1e293b;font-weight:bold}

/* ===== TABLE ===== */
table{width:100%;border-collapse:collapse;margin-top:${forExcel ? '4px' : '0'}}
th{background:#047857;color:#fff;font-weight:bold;font-size:${forExcel ? '12pt' : '13pt'};padding:${forExcel ? '8px 6px' : '12px 10px'};border:1px solid #065f46;text-align:center;mso-number-format:'\\@'}
td{padding:${forExcel ? '7px 6px' : '10px 8px'};border:1px solid #e2e8f0;font-size:${forExcel ? '11pt' : '12pt'};text-align:center;vertical-align:middle;mso-number-format:'\\@'}
td.name{text-align:right;font-weight:bold;color:#1e293b;font-size:${forExcel ? '12pt' : '13pt'}}
td.phone{text-align:center;direction:ltr;letter-spacing:0.5px;color:#334155}
td.district{text-align:right;color:#475569}
td.num{text-align:center;color:#64748b;font-weight:bold;font-size:${forExcel ? '10pt' : '11pt'}}
tr:nth-child(even) td{background:#f0fdf4}
tr:nth-child(odd) td{background:#ffffff}

/* ===== FOOTER ===== */
.footer{text-align:center;margin-top:${forExcel ? '8px' : '24px'};font-size:8pt;color:#94a3b8;padding-top:8px;border-top:1px solid #e2e8f0}

@media print{body{padding:10px}.banner{padding:14px 18px;border-radius:0}}
</style></head><body>

<div class="banner">
<h1>سِجلّ</h1>
<p class="sub">تقرير بيانات الطلاب</p>
</div>

${forExcel ? '<table style="margin-bottom:4px"><tr>' : '<div class="cards">'}
${forExcel ? `
<td class="card"><div class="card-label">تاريخ التصدير</div><div class="card-value">${todayStr}</div></td>
<td class="card"><div class="card-label">المشروع</div><div class="card-value">${projectName || '—'}</div></td>
<td class="card"><div class="card-label">عدد الطلاب</div><div class="card-value">${projectBen.length} (${numActive} نشط)</div></td>
` : `
<div class="card"><div class="card-label">تاريخ التصدير</div><div class="card-value">${todayStr}</div></div>
<div class="card"><div class="card-label">المشروع</div><div class="card-value">${projectName || '—'}</div></div>
<div class="card"><div class="card-label">عدد الطلاب</div><div class="card-value">${projectBen.length} (${numActive} نشط)</div></div>
`}
${forExcel ? '</tr></table>' : '</div>'}

<table>
<thead><tr>
<th style="width:${forExcel ? '40px' : '45px'}">م</th>
<th>اسم الطالب</th>
<th style="width:${forExcel ? '110px' : '130px'}">رقم الجوال</th>
<th style="width:${forExcel ? '110px' : '130px'}">الحي</th>
</tr></thead>
<tbody>
${projectBen.map((b,i)=>{
const name=(b.name||'').replace(/^\d+[-–.\s]+/,'').trim();
return `<tr><td class="num">${i+1}</td><td class="name">${name}</td><td class="phone">${b.phone||''}</td><td class="district">${b.district||''}</td></tr>`;
}).join('')}
</tbody>
</table>

<div class="footer">تم إنشاء هذا التقرير من تطبيق سِجلّ — ${todayStr}</div>
</body></html>`;
  };

  const finalizeExport = (type: 'excel' | 'pdf' | 'daily', fileName: string, html: string, mime: string) => {
    const blob = new Blob([type === 'excel' ? '\uFEFF' + html : html], { type: mime });
    const blobUrl = URL.createObjectURL(blob);
    setExportResult({ type, fileName, blob, blobUrl, htmlContent: html });
  };

  const exportExcel = () => {
    setExporting('excel');
    try {
      const html = buildReportHTML(true);
      const fileName = `تقرير_الطلاب_${new Date().toISOString().split('T')[0]}.xls`;
      finalizeExport('excel', fileName, html, 'application/vnd.ms-excel;charset=utf-8');
    } catch (err) {
      console.error(err);
    } finally {
      setExporting('');
    }
  };

  const exportPDF = () => {
    setExporting('pdf');
    try {
      const html = buildReportHTML(false);
      const fileName = `تقرير_الطلاب_${new Date().toISOString().split('T')[0]}.html`;
      finalizeExport('pdf', fileName, html, 'text/html;charset=utf-8');
    } catch (err) {
      console.error(err);
    } finally {
      setExporting('');
    }
  };

  const exportDailyPDF = () => {
    setExporting('daily-pdf');
    try {
      const statusLabel = (s: string) => s === 'present' ? 'حاضر' : s === 'absent' ? 'غائب' : 'متأخر';
      const statusColor = (s: string) => s === 'present' ? '#059669' : s === 'absent' ? '#dc2626' : '#d97706';
      const html = `<html dir="rtl"><head><meta charset="utf-8">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,Tahoma,sans-serif;direction:rtl;text-align:right;color:#1e293b;padding:24px}
h1{text-align:center;font-size:20pt;color:#1e40af;margin-bottom:4px}
.date{text-align:center;color:#64748b;font-size:12pt;margin-bottom:18px;padding-bottom:12px;border-bottom:2px solid #3b82f6}
table{width:100%;border-collapse:collapse}
th{background:#1e40af;color:#fff;font-weight:bold;font-size:12pt;padding:10px 8px;border:1px solid #1e3a8a;text-align:center}
td{padding:8px;border:1px solid #e2e8f0;font-size:11pt;text-align:center}
td.name{text-align:right;font-weight:bold}
tr:nth-child(even) td{background:#f8fafc}
@media print{body{padding:10px}h1{font-size:16pt}}
</style></head><body>
<h1>تقرير الحضور اليومي</h1>
<div class="date">${selectedDate}</div>
<table><thead><tr><th style="width:40px">م</th><th>المستفيد</th><th style="width:130px">المجموعة</th><th style="width:90px">الحالة</th></tr></thead>
<tbody>${dailyAttendance.map((a,i)=>{
const ben = beneficiaries.find((b)=>b.id===a.beneficiaryId);
return `<tr><td>${i+1}</td><td class="name">${ben?.name||''}</td><td>${getGroupName(a.groupId)}</td><td style="color:${statusColor(a.status)};font-weight:bold">${statusLabel(a.status)}</td></tr>`;
}).join('')}</tbody></table></body></html>`;
      const fileName = `تقرير_يومي_${selectedDate}.html`;
      finalizeExport('daily', fileName, html, 'text/html;charset=utf-8');
    } catch (err) {
      console.error(err);
    } finally {
      setExporting('');
    }
  };

  const closeExport = () => {
    if (exportResult?.blobUrl) URL.revokeObjectURL(exportResult.blobUrl);
    setExportResult(null);
    setShowPreview(false);
  };

  const handleShare = async () => {
    if (!exportResult) return;
    try {
      const file = new File([exportResult.blob], exportResult.fileName, { type: exportResult.blob.type });
      const nav = navigator as any;
      if (nav.canShare && nav.canShare({ files: [file] })) {
        await nav.share({ files: [file], title: 'تقرير سِجلّ', text: 'تقرير من تطبيق سِجلّ' });
      } else if (nav.share) {
        await nav.share({ title: 'تقرير سِجلّ', text: exportResult.fileName });
      } else {
        // Fallback: download
        const a = document.createElement('a');
        a.href = exportResult.blobUrl;
        a.download = exportResult.fileName;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
      }
    } catch (err) {
      console.error('Share error:', err);
    }
  };

  const handleDownload = () => {
    if (!exportResult) return;
    const a = document.createElement('a');
    a.href = exportResult.blobUrl;
    a.download = exportResult.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">التقارير</h2>
          <p className="text-slate-500 mt-1 text-sm">تحليل وتصدير بيانات النظام</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button onClick={exportExcel} disabled={!!exporting} className="flex items-center gap-1.5 px-3.5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition-colors shadow-sm disabled:opacity-50">
            {exporting === 'excel' ? <Loader2 size={14} className="animate-spin" /> : <FileSpreadsheet size={15} />}
            تصدير إكسل
          </button>
          <button onClick={exportPDF} disabled={!!exporting} className="flex items-center gap-1.5 px-3.5 py-2.5 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700 transition-colors shadow-sm disabled:opacity-50">
            {exporting === 'pdf' ? <Loader2 size={14} className="animate-spin" /> : <FileText size={15} />}
            تصدير PDF
          </button>
        </div>
      </div>

      {/* Report Tabs */}
      <div className="flex gap-2 bg-slate-100 p-1 rounded-xl w-fit">
        {[
          { id: 'overview' as const, label: 'نظرة عامة' },
          { id: 'daily' as const, label: 'تقرير يومي' },
          { id: 'project' as const, label: 'تقرير مشروع' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setReportType(tab.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              reportType === tab.id ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-4 text-white">
          <p className="text-3xl font-bold">{beneficiaries.length}</p>
          <p className="text-xs text-blue-100 mt-1">إجمالي المستفيدين</p>
        </div>
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl p-4 text-white">
          <p className="text-3xl font-bold">{projects.length}</p>
          <p className="text-xs text-emerald-100 mt-1">المشاريع</p>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-4 text-white">
          <p className="text-3xl font-bold">{groups.length}</p>
          <p className="text-xs text-purple-100 mt-1">المجموعات</p>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl p-4 text-white">
          <p className="text-3xl font-bold">{attendance.length}</p>
          <p className="text-xs text-amber-100 mt-1">سجلات الحضور</p>
        </div>
      </div>

      {/* OVERVIEW */}
      {reportType === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
            <h3 className="text-base font-bold text-slate-800 mb-4">المستفيدين حسب المشروع</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={projectData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis />
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 15px rgba(0,0,0,0.1)' }} />
                <Bar dataKey="active" name="نشط" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="ended" name="منتهي" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
            <h3 className="text-base font-bold text-slate-800 mb-4">توزيع الحالات</h3>
            <div className="flex items-center">
              <ResponsiveContainer width="60%" height={250}>
                <PieChart>
                  <Pie data={statusData} cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={5} dataKey="value">
                    {statusData.map((_e, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2">
                {statusData.map((item, i) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                    <span className="text-sm text-slate-600">{item.name}: <strong>{item.value}</strong></span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
            <h3 className="text-base font-bold text-slate-800 mb-4">التوزيع العمري</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={ageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" name="عدد" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {attendanceData.some((d) => d.rate > 0) && (
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <h3 className="text-base font-bold text-slate-800 mb-4">نسبة الحضور بالمجموعات</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={attendanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(v: any) => `${v}%`} />
                  <Bar dataKey="rate" name="نسبة الحضور" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* DAILY REPORT */}
      {reportType === 'daily' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Calendar size={18} className="text-slate-500" />
                <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
              </div>
              <button onClick={exportDailyPDF} disabled={!!exporting} className="flex items-center gap-1.5 px-3 py-2 bg-red-50 text-red-700 rounded-xl text-xs font-medium hover:bg-red-100 transition-colors disabled:opacity-50">
                {exporting === 'daily-pdf' ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />}
                تصدير PDF يومي
              </button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-emerald-700">{dailyPresent}</p>
              <p className="text-xs text-emerald-600 mt-1">حاضر</p>
            </div>
            <div className="bg-red-50 border border-red-100 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-red-700">{dailyAbsent}</p>
              <p className="text-xs text-red-600 mt-1">غائب</p>
            </div>
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-amber-700">{dailyLate}</p>
              <p className="text-xs text-amber-600 mt-1">متأخر</p>
            </div>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">م</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">المستفيد</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">المجموعة</th>
                  <th className="text-center px-4 py-3 text-xs font-bold text-slate-600">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {dailyAttendance.map((a, i) => {
                  const ben = beneficiaries.find((b) => b.id === a.beneficiaryId);
                  return (
                    <tr key={a.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                      <td className="px-4 py-2.5 text-xs text-slate-400">{i + 1}</td>
                      <td className="px-4 py-2.5 text-sm font-medium text-slate-800">{ben?.name || '—'}</td>
                      <td className="px-4 py-2.5 text-xs text-slate-500">{getGroupName(a.groupId)}</td>
                      <td className="px-4 py-2.5 text-center">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          a.status === 'present' ? 'bg-emerald-100 text-emerald-700' :
                          a.status === 'absent' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {a.status === 'present' ? 'حاضر' : a.status === 'absent' ? 'غائب' : 'متأخر'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {dailyAttendance.length === 0 && <div className="p-12 text-center text-slate-400 text-sm">لا توجد سجلات لهذا اليوم</div>}
          </div>
        </div>
      )}

      {/* PROJECT REPORT */}
      {reportType === 'project' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4">
            <div className="flex items-center gap-3">
              <FolderOpen size={18} className="text-slate-500" />
              <h3 className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>تقرير المشروع الحالي</h3>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-blue-700">{projectBeneficiaries.length}</p>
              <p className="text-xs text-blue-600 mt-1">إجمالي</p>
            </div>
            <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-emerald-700">{projectBeneficiaries.filter((b) => b.status === 'active').length}</p>
              <p className="text-xs text-emerald-600 mt-1">نشط</p>
            </div>
            <div className="bg-red-50 border border-red-100 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-red-700">{projectBeneficiaries.filter((b) => b.status !== 'active').length}</p>
              <p className="text-xs text-red-600 mt-1">منتهي/مؤرشف</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">م</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">الاسم</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">الرقم</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">المجموعة</th>
                  <th className="text-center px-4 py-3 text-xs font-bold text-slate-600">الحالة</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">البداية</th>
                  <th className="text-right px-4 py-3 text-xs font-bold text-slate-600">النهاية</th>
                </tr>
              </thead>
              <tbody>
                {projectBeneficiaries.map((b, i) => (
                  <tr key={b.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                    <td className="px-4 py-2.5 text-xs text-slate-400">{i + 1}</td>
                    <td className="px-4 py-2.5 text-sm font-medium text-slate-800">{b.name}</td>
                    <td className="px-4 py-2.5 text-sm text-slate-600">{b.number}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-500">{getGroupName(b.groupId)}</td>
                    <td className="px-4 py-2.5 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        b.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                      }`}>
                        {b.status === 'active' ? 'نشط' : 'منتهي'}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-slate-500">{b.startDate}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-500">{b.endDate}</td>
                   </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Export Success Modal — Apple style sheet */}
      {exportResult && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-fade-in"
          style={{ backgroundColor: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)' }}
          onClick={closeExport}
        >
          <div
            className={`rounded-2xl border w-full shadow-2xl flex flex-col overflow-hidden ${showPreview ? 'max-w-4xl h-[88vh]' : 'max-w-md'}`}
            style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
            onClick={(e) => e.stopPropagation()}
          >
            {showPreview ? (
              <>
                {/* Preview header */}
                <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-input)' }}>
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center text-white text-xs font-bold shrink-0">📄</div>
                    <div className="min-w-0">
                      <p className="text-sm font-bold truncate" style={{ color: 'var(--text-primary)' }}>{exportResult.fileName}</p>
                      <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>معاينة الملف</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowPreview(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold border hover:bg-[var(--bg-card-hover)] shrink-0"
                    style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  >
                    رجوع
                  </button>
                </div>

                {/* Preview iframe */}
                <iframe
                  srcDoc={exportResult.htmlContent}
                  title="معاينة"
                  className="flex-1 w-full bg-white"
                  style={{ border: 'none' }}
                />

                {/* Preview actions */}
                <div className="flex gap-2 p-3 border-t" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-input)' }}>
                  <button
                    onClick={handleShare}
                    className="flex-1 py-2.5 rounded-xl text-sm font-bold bg-blue-500 hover:bg-blue-600 text-white active:scale-95 transition-all flex items-center justify-center gap-1.5"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                    مشاركة
                  </button>
                  <button
                    onClick={handleDownload}
                    className="flex-1 py-2.5 rounded-xl text-sm font-bold bg-emerald-500 hover:bg-emerald-600 text-white active:scale-95 transition-all flex items-center justify-center gap-1.5"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    تنزيل
                  </button>
                </div>
              </>
            ) : (
              <div className="p-6">
                {/* Success icon */}
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center bg-emerald-100 dark:bg-emerald-900/30">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                </div>

                <h3 className="text-lg font-bold text-center mb-2" style={{ color: 'var(--text-primary)' }}>
                  تم تصدير الملف بنجاح ✅
                </h3>
                <p className="text-sm text-center mb-1" style={{ color: 'var(--text-secondary)' }}>
                  يمكنك الآن فتح الملف أو مشاركته
                </p>
                <p className="text-[11px] text-center mb-6 font-mono px-3 py-1.5 rounded-lg mx-auto inline-block w-full" style={{ color: 'var(--text-muted)', backgroundColor: 'var(--bg-input)' }}>
                  {exportResult.fileName}
                </p>

                <div className="space-y-2">
                  <button
                    onClick={handleShare}
                    className="w-full py-3 rounded-xl text-sm font-bold bg-blue-500 hover:bg-blue-600 text-white active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-sm"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                    مشاركة الملف
                  </button>
                  <button
                    onClick={() => setShowPreview(true)}
                    className="w-full py-3 rounded-xl text-sm font-bold bg-gradient-to-l from-emerald-500 to-emerald-600 hover:shadow-lg text-white active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    فتح الملف داخل التطبيق
                  </button>
                  <button
                    onClick={closeExport}
                    className="w-full py-3 rounded-xl text-sm font-bold border hover:bg-[var(--bg-card-hover)] transition-colors"
                    style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  >
                    العودة إلى التطبيق
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
