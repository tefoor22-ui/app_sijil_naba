import { useStore } from '../store/useStore';
import {
  LayoutDashboard, Users, FolderOpen, Layers, ClipboardCheck,
  BarChart3, Archive, ScrollText, Settings, X, UserPlus,
  Moon, Sun,
} from 'lucide-react';

const menuItems = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { id: 'add-beneficiary', label: 'إضافة مستفيد', icon: UserPlus },
  { id: 'beneficiaries', label: 'سجل المستفيدين', icon: Users },
  { id: 'projects', label: 'المشاريع', icon: FolderOpen },
  { id: 'groups', label: 'المجموعات', icon: Layers },
  { id: 'attendance', label: 'الحضور والغياب', icon: ClipboardCheck },
  { id: 'reports', label: 'التقارير', icon: BarChart3 },
  { id: 'archive', label: 'الأرشيف', icon: Archive },
  { id: 'activity-log', label: 'سجل العمليات', icon: ScrollText },
  { id: 'settings', label: 'الإعدادات', icon: Settings },
];

export default function Sidebar() {
  const { currentPage, setCurrentPage, sidebarOpen, setSidebarOpen, settings, toggleDarkMode } = useStore();

  return (
    <>
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside
        className={`fixed top-0 right-0 h-full w-[280px] z-50 transform transition-transform duration-300 ease-out lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        } flex flex-col shadow-2xl`}
        style={{ background: 'var(--bg-sidebar)' }}
      >
        {/* Logo Header */}
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/logo.png" alt="سِجلّ" className="w-11 h-11 rounded-[14px] shadow-lg" draggable={false} />
              <div>
                <h1 className="font-bold text-[16px] text-white">سِجلّ</h1>
                <p className="text-[11px] text-slate-400">نظام إدارة الطلاب والمستفيدين</p>
              </div>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1.5 hover:bg-white/10 rounded-xl transition-colors text-slate-400">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-4 pt-4 pb-2">
          <button
            onClick={toggleDarkMode}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-slate-300 text-xs"
          >
            {settings.darkMode ? <Sun size={14} /> : <Moon size={14} />}
            {settings.darkMode ? 'الوضع الفاتح' : 'الوضع الليلي'}
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-2 px-3 space-y-0.5">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-[13px] font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-l from-emerald-600/90 to-blue-600/90 text-white shadow-lg shadow-blue-600/20'
                    : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon size={19} strokeWidth={isActive ? 2.2 : 1.8} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-white/10">
          <div className="text-center">
            <p className="text-[11px] text-slate-500 font-bold">تطبيق سِجلّ</p>
            <p className="text-[10px] text-slate-600">الإصدار 3.0.0</p>
          </div>
        </div>
      </aside>
    </>
  );
}
