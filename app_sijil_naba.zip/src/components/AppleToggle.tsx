interface AppleToggleProps {
  checked: boolean;
  onChange: () => void;
  size?: 'sm' | 'md';
  disabled?: boolean;
}

export default function AppleToggle({ checked, onChange, size = 'md', disabled = false }: AppleToggleProps) {
  const isSm = size === 'sm';
  const w = isSm ? 48 : 56;
  const h = isSm ? 24 : 28;
  const knobW = isSm ? 18 : 22;
  const knobH = isSm ? 18 : 22;
  const pad = 3;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={onChange}
      disabled={disabled}
      style={{
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'center',
        width: w,
        height: h,
        borderRadius: 8,
        padding: 0,
        border: 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        outline: 'none',
        flexShrink: 0,
        backgroundColor: checked ? '#2F7A3A' : '#d1d5db',
        boxShadow: checked
          ? 'inset 0 1px 2px rgba(0,0,0,0.12), 0 0 6px rgba(47,122,58,0.2)'
          : 'inset 0 1px 2px rgba(0,0,0,0.08)',
        transition: 'background-color 0.2s ease, box-shadow 0.2s ease',
        WebkitTapHighlightColor: 'transparent',
      }}
    >
      <span
        style={{
          position: 'absolute',
          top: pad,
          width: knobW,
          height: knobH,
          borderRadius: 6,
          backgroundColor: '#fff',
          boxShadow: '0 1px 4px rgba(0,0,0,0.15), 0 1px 1px rgba(0,0,0,0.06)',
          transition: 'right 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          right: checked ? pad : (w - knobW - pad),
        }}
      />
    </button>
  );
}
