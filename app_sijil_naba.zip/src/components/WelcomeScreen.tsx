import { useStore } from '../store/useStore';

export default function WelcomeScreen() {
  const { updateSettings } = useStore();

  return (
    <div className="fixed inset-0 z-[8888] flex flex-col items-center justify-center p-6"
      style={{ background: 'radial-gradient(circle at 50% 30%, #0d2818 0%, #050f0a 100%)' }}>

      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/5 blur-[100px] rounded-full" />

      <div className="flex flex-col items-center max-w-sm w-full animate-fade-in">
        {/* Logo — as-is, no text overlay */}
        <div className="mb-8 relative">
          <div className="absolute inset-[-12px] bg-emerald-500/15 blur-3xl rounded-full" />
          <img src="/logo.png" alt="سِجلّ" draggable={false}
            className="w-28 h-28 rounded-[24px] shadow-2xl relative z-10" />
        </div>

        <h1 className="text-3xl font-black text-white mb-2">سِجلّ</h1>
        <p className="text-emerald-400/70 text-sm font-medium mb-12 leading-relaxed text-center">
          إدارة المستفيدين والطلاب بكل سهولة
        </p>

        <button
          onClick={() => updateSettings({ hasSeenWelcome: true })}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold rounded-2xl transition-all duration-300 shadow-[0_0_24px_rgba(16,185,129,0.3)] hover:shadow-[0_0_36px_rgba(16,185,129,0.5)] active:scale-95 text-base"
        >
          ابدأ الآن
        </button>
      </div>

      <p className="absolute bottom-8 text-white/15 text-[10px]">الإصدار 3.0</p>
    </div>
  );
}
