import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useStore } from '../store/useStore';
import PDFViewer from './PDFViewer';
import AppleToggle from './AppleToggle';
import { Save, Undo2, CheckCircle } from 'lucide-react';

const emptyForm = {
  name: '', phone: '', number: '', age: '', district: '', startDate: '', endDate: '',
  notes: '', groupId: '', projectId: '', status: 'active' as const, fileData: '',
};

export default function AddBeneficiary() {
  const { addBeneficiary, settings, currentProjectId, beneficiaries } = useStore();
  const [quickEntry, setQuickEntry] = useState(false);
  const [form, setForm] = useState({ ...emptyForm });
  const [history, setHistory] = useState<typeof form[]>([]);
  const [saved, setSaved] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [autoSaveTimer, setAutoSaveTimer] = useState<ReturnType<typeof setTimeout> | null>(null);
  const inputRefs = useRef<(HTMLInputElement | HTMLTextAreaElement | null)[]>([]);
  const formRef = useRef<HTMLDivElement>(null);

  const pushHistory = useCallback(() => {
    setHistory((prev) => [...prev.slice(-20), { ...form }]);
  }, [form]);

  const handleUndo = () => {
    if (history.length > 0) {
      setForm(history[history.length - 1]);
      setHistory((h) => h.slice(0, -1));
    }
  };

  const updateField = (field: string, value: string) => {
    pushHistory();
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((e) => { const n = { ...e }; delete n[field]; return n; });
    if (autoSaveTimer) clearTimeout(autoSaveTimer);
    const timer = setTimeout(() => {
      try { localStorage.setItem('beneficiary-draft', JSON.stringify({ ...form, [field]: value })); } catch {}
    }, 800);
    setAutoSaveTimer(timer);
  };

  useEffect(() => {
    try {
      const draft = localStorage.getItem('beneficiary-draft');
      if (draft) { const parsed = JSON.parse(draft); if (parsed.name || parsed.phone) setForm(parsed); }
    } catch {}
  }, []);

  useEffect(() => {
    if (currentProjectId) setForm((prev) => ({ ...prev, projectId: currentProjectId }));
  }, [currentProjectId]);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) {
      errs.name = 'الاسم الكامل مطلوب';
    } else if (!/^[\u0600-\u06FFa-zA-Z\s]+$/.test(form.name.trim())) {
      errs.name = 'الاسم يجب أن يحتوي على حروف فقط (بدون أرقام أو رموز)';
    }

    if (!form.phone.trim()) {
      errs.phone = 'رقم الجوال مطلوب';
    } else if (!/^05\d{8}$/.test(form.phone.trim())) {
      errs.phone = 'رقم الجوال غير صحيح، يجب أن يبدأ بـ 05 ويتكون من 10 أرقام';
    }
    
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) {
      const firstErrorField = Object.keys(errors)[0] || 'name';
      const idx = fields.findIndex((f) => f.key === firstErrorField);
      if (idx >= 0 && inputRefs.current[idx]) inputRefs.current[idx]?.focus();
      return;
    }
    // In Quick Mode, only save the 3 visible fields and clear the hidden ones
    const submission = quickEntry
      ? {
          ...emptyForm,
          name: form.name,
          phone: form.phone,
          district: form.district,
          fileData: form.fileData,
          projectId: currentProjectId,
        }
      : { ...form, projectId: currentProjectId };

    addBeneficiary(submission);
    setForm({ ...emptyForm });
    setHistory([]);
    setErrors({});
    setSaved(true);
    localStorage.removeItem('beneficiary-draft');
    setTimeout(() => setSaved(false), 3000);
  };

  const handleFileLoaded = (dataUrl: string) => {
    pushHistory();
    setForm((prev) => ({ ...prev, fileData: dataUrl }));
  };

  const handleKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const next = inputRefs.current[index + 1];
      if (next) next.focus();

    }
  };

  const fields = [
    { key: 'name', label: 'الاسم الكامل', type: 'text', placeholder: 'أدخل الاسم الكامل', required: true },
    { key: 'phone', label: 'رقم الجوال', type: 'tel', placeholder: '05XXXXXXXX', required: true },
    { key: 'district', label: 'الحي', type: 'text', placeholder: 'اختياري' },
    { key: 'age', label: 'العمر', type: 'number', placeholder: 'اختياري' },
  ];

  const dateFields = [
    { key: 'startDate', label: 'تاريخ البداية', type: 'date', placeholder: '' },
    { key: 'endDate', label: 'تاريخ النهاية', type: 'date', placeholder: '' },
  ];

  const labelColor = { color: 'var(--text-secondary)' };
  const cardBg = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };

  // Check for duplicate names in the current project — computed once at component level
  const isDuplicateName = useMemo(() => {
    if (!form.name.trim()) return false;
    return beneficiaries.some(
      (b) => b.projectId === currentProjectId &&
             b.status === 'active' &&
             b.name.trim().toLowerCase() === form.name.trim().toLowerCase()
    );
  }, [form.name, currentProjectId, beneficiaries]);

  const renderInput = (
    field: { key: string; label: string; type: string; placeholder: string; required?: boolean },
    idx: number,
    className = ''
  ) => {
    const isPhoneField = field.key === 'phone';
    const isNameField = field.key === 'name';

    return (
      <div key={field.key} className={`min-w-0 ${className}`}>
        <label className="block text-xs font-semibold mb-1.5" style={labelColor}>
          {field.label}
          {field.required && <span className="text-red-500 mr-1">*</span>}
        </label>
        <input
          ref={(el) => { inputRefs.current[idx] = el; }}
          type={isPhoneField ? 'tel' : field.type}
          inputMode={isPhoneField ? 'numeric' : field.type === 'number' ? 'numeric' : 'text'}
          pattern={isPhoneField ? '[0-9]*' : undefined}
          maxLength={isPhoneField ? 10 : undefined}
          value={(form as any)[field.key]}
          onChange={(e) => {
            let val = e.target.value;
            if (isPhoneField) val = val.replace(/\D/g, '').substring(0, 10);
            updateField(field.key, val);
          }}
          onKeyDown={(e) => handleKeyDown(e, idx)}
          onFocus={(e) => setTimeout(() => e.currentTarget.scrollIntoView({ behavior: 'smooth', block: 'center' }), 250)}
          placeholder={field.placeholder}
          enterKeyHint="next"
          className={`field-input ${errors[field.key] ? 'field-error' : ''}`}
        />
        {errors[field.key] && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors[field.key]}</p>}
        {isNameField && isDuplicateName && (
          <p className="text-amber-600 dark:text-amber-400 text-[10px] mt-1.5 font-medium bg-amber-50 dark:bg-amber-900/30 px-2.5 py-1.5 rounded-lg border border-amber-200/50 dark:border-amber-800/50 flex items-center gap-1.5">
            ⚠️ تنبيه: تشابه أسماء! هذا الطالب مسجل مسبقاً في هذا المشروع.
          </p>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>إضافة مستفيد جديد</h2>
          <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>أدخل البيانات بمراجعة الصورة في نفس الوقت</p>
        </div>
        <button onClick={handleUndo} disabled={history.length === 0}
          className="p-2 rounded-xl border transition-colors disabled:opacity-30 hover:bg-[var(--bg-card-hover)]"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>
          <Undo2 size={18} />
        </button>
      </div>

      {saved && (
        <div className="bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800 rounded-xl p-3 flex items-center gap-3 animate-fade-in">
          <CheckCircle size={20} className="text-emerald-600 dark:text-emerald-400" />
          <span className="text-emerald-700 dark:text-emerald-300 font-medium text-sm">تم حفظ المستفيد بنجاح ✓</span>
        </div>
      )}

      {/* Side-by-side layout on desktop, stacked on mobile */}
      <div className="flex flex-col lg:flex-row gap-4 lg:gap-5 lg:items-start">
        {/* Preview Pane — RIGHT side in RTL (since everything is RTL, this appears left visually on RTL) */}
        <div className="w-full lg:w-1/2 lg:sticky lg:top-16 z-10">
          <PDFViewer onFileLoaded={handleFileLoaded} />
        </div>

        {/* Form Panel — LEFT side in RTL (appears right visually) */}
        <div
          ref={formRef}
          className="w-full lg:w-1/2 rounded-2xl border p-4 sm:p-5 transition-colors"
          style={cardBg}
        >
          <div className="mb-4">
            <h3 className="text-base font-bold mb-3" style={{ color: 'var(--text-primary)' }}>بيانات المستفيد</h3>

            {/* Quick Mode toggle — clear and prominent */}
            <div
              className="flex items-center justify-between rounded-xl p-3 border transition-colors cursor-pointer"
              style={{
                backgroundColor: quickEntry ? 'rgba(16,185,129,0.08)' : 'var(--bg-input)',
                borderColor: quickEntry ? '#10b981' : 'var(--border-color)',
              }}
              onClick={() => setQuickEntry(!quickEntry)}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0"
                  style={{
                    backgroundColor: quickEntry ? '#10b981' : 'var(--bg-card)',
                    color: quickEntry ? '#ffffff' : 'var(--text-muted)',
                  }}
                >
                  ⚡
                </div>
                <div>
                  <p className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>الوضع السريع</p>
                  <p className="text-[10px] mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {quickEntry ? 'يظهر فقط: الاسم، الجوال، الحي' : 'تفعيله يخفي العمر والتواريخ والملاحظات'}
                  </p>
                </div>
              </div>
              <AppleToggle checked={quickEntry} onChange={() => setQuickEntry(!quickEntry)} size="sm" />
            </div>
          </div>

          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
              {fields
                .filter((f) => !quickEntry || ['name', 'phone', 'district'].includes(f.key))
                .map((field) => renderInput(field, fields.findIndex((x) => x.key === field.key)))}
            </div>

            {/* Fixed date row */}
            {!quickEntry && (
              <div className="flex flex-row gap-3 items-start w-full">
                {dateFields.map((field, dateIdx) => renderInput(field, fields.length + dateIdx, 'flex-1 basis-0'))}
              </div>
            )}

            {/* Notes */}
            {!quickEntry && (
              <div>
                <label className="block text-xs font-semibold mb-1.5" style={labelColor}>ملاحظات</label>
                <textarea
                  ref={(el) => { inputRefs.current[fields.length + dateFields.length] = el; }}
                  value={form.notes}
                  onChange={(e) => updateField('notes', e.target.value)}
                  onFocus={(e) => setTimeout(() => e.currentTarget.scrollIntoView({ behavior: 'smooth', block: 'center' }), 250)}
                  placeholder="اختياري"
                  rows={2}
                  className="field-input"
                />
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="mt-5 flex items-center gap-3 flex-wrap">
            <button onClick={handleSubmit}
              className="flex items-center gap-2 px-5 sm:px-6 py-2.5 sm:py-3 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl font-medium hover:shadow-lg transition-all active:scale-95 text-sm">
              <Save size={17} />
              حفظ المستفيد
            </button>
            <button onClick={() => { pushHistory(); setForm({ ...emptyForm }); setErrors({}); localStorage.removeItem('beneficiary-draft'); }}
              className="px-5 py-2.5 rounded-xl font-medium transition-all text-sm"
              style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>
              مسح النموذج
            </button>
            {settings.autoSave && (
              <span className="text-[10px] mr-auto flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                حفظ تلقائي
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
