import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Plus, Edit3, Trash2, FolderOpen, X, Save } from 'lucide-react';

const emptyProject = { name: '', description: '', status: 'active' as const, startDate: '', endDate: '' };

export default function Projects() {
  const { projects, beneficiaries, addProject, updateProject, deleteProject, settings } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyProject });

  const handleSubmit = () => { if (!form.name.trim()) return; editingId ? updateProject(editingId, form) : addProject(form); setForm({ ...emptyProject }); setShowForm(false); setEditingId(null); };
  const startEdit = (p: any) => { setEditingId(p.id); setForm({ name: p.name, description: p.description, status: p.status, startDate: p.startDate, endDate: p.endDate }); setShowForm(true); };

  const statusColors: Record<string, string> = { active: 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400', paused: 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400', ended: 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400' };
  const statusLabels: Record<string, string> = { active: 'نشط', paused: 'متوقف', ended: 'منتهي' };
  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };
  const modalBg = settings.darkMode ? 'rgba(0,0,0,0.7)' : 'rgba(0,0,0,0.5)';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>المشاريع</h2>
          <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>إدارة المشاريع</p>
        </div>
        <button onClick={() => { setShowForm(true); setEditingId(null); setForm({ ...emptyProject }); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all active:scale-95">
          <Plus size={17} /> إضافة مشروع
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: modalBg }} onClick={() => setShowForm(false)}>
          <div className="rounded-2xl max-w-lg w-full p-5 animate-fade-in" style={cardStyle} onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>{editingId ? 'تعديل' : 'إضافة'} مشروع</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-[var(--bg-card-hover)]"><X size={18} style={{ color: 'var(--text-muted)' }} /></button>
            </div>
            <div className="space-y-3">
              <div><label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>الاسم *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3.5 py-2.5 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30" style={inputStyle} placeholder="اسم المشروع" /></div>
              <div><label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>الوصف</label>
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full px-3.5 py-2.5 border rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/30" rows={3} style={inputStyle} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>البداية</label>
                  <input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} className="w-full px-3 py-2.5 border rounded-xl text-sm" style={inputStyle} /></div>
                <div><label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>النهاية</label>
                  <input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} className="w-full px-3 py-2.5 border rounded-xl text-sm" style={inputStyle} /></div>
              </div>
              <div><label className="block text-xs font-semibold mb-1" style={{ color: 'var(--text-muted)' }}>الحالة</label>
                <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="w-full px-3 py-2.5 border rounded-xl text-sm" style={inputStyle}>
                  <option value="active">نشط</option><option value="paused">متوقف</option><option value="ended">منتهي</option></select></div>
              <div className="flex gap-2 pt-2">
                <button onClick={handleSubmit} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-xl text-sm font-medium active:scale-95"><Save size={15} /> {editingId ? 'تحديث' : 'إضافة'}</button>
                <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-xl text-sm" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {projects.map((project) => {
          const count = beneficiaries.filter((b) => b.projectId === project.id && b.status !== 'archived').length;
          return (
            <div key={project.id} className="rounded-2xl border p-4 sm:p-5 transition-colors" style={cardStyle}>
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mt-0.5 shrink-0">
                    <FolderOpen size={20} className="text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>{project.name}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColors[project.status]}`}>{statusLabels[project.status]}</span>
                    </div>
                    <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{project.description}</p>
                    <div className="flex items-center gap-4 mt-2 text-[10px]" style={{ color: 'var(--text-muted)' }}>
                      <span>{count} مستفيد</span>
                      {project.startDate && <span>من: {project.startDate}</span>}
                      {project.endDate && <span>إلى: {project.endDate}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => startEdit(project)} className="p-1.5 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-900/30 hover:text-amber-600 transition-colors" style={{ color: 'var(--text-muted)' }}><Edit3 size={15} /></button>
                  <button onClick={() => { if (confirm('حذف؟')) deleteProject(project.id); }} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30 hover:text-red-600 transition-colors" style={{ color: 'var(--text-muted)' }}><Trash2 size={15} /></button>
                </div>
              </div>
            </div>
          );
        })}
        {projects.length === 0 && <div className="rounded-2xl border p-12 text-center transition-colors" style={cardStyle}><p style={{ color: 'var(--text-muted)' }}>لا توجد مشاريع</p></div>}
      </div>
    </div>
  );
}
