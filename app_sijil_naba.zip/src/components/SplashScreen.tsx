import { useEffect, useState } from 'react';

interface SplashScreenProps {
  onFinish: () => void;
}

export default function SplashScreen({ onFinish }: SplashScreenProps) {
  const [phase, setPhase] = useState<'enter' | 'hold' | 'exit'>('enter');

  useEffect(() => {
    const t1 = setTimeout(() => setPhase('hold'), 100);
    const t2 = setTimeout(() => setPhase('exit'), 2200);
    const t3 = setTimeout(() => onFinish(), 2700);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onFinish]);

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center"
      style={{
        background: 'radial-gradient(ellipse at 50% 40%, #112a18 0%, #0a1a0e 50%, #050d07 100%)',
        opacity: phase === 'exit' ? 0 : 1,
        transition: phase === 'exit' ? 'opacity 0.5s ease-out' : 'none',
      }}
    >
      {/* Glow */}
      <div style={{
        position: 'absolute',
        width: 300, height: 300, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(34,197,94,0.15) 0%, transparent 70%)',
        filter: 'blur(40px)',
        opacity: phase === 'hold' ? 1 : 0,
        transform: phase === 'hold' ? 'scale(1)' : 'scale(0.5)',
        transition: 'all 1.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }} />

      {/* Logo — NO modifications, just the image */}
      <img
        src="/logo.png"
        alt="سِجلّ"
        draggable={false}
        style={{
          width: 140, height: 140,
          borderRadius: 32,
          display: 'block',
          position: 'relative',
          zIndex: 1,
          boxShadow: phase === 'hold'
            ? '0 0 60px 16px rgba(34,197,94,0.2), 0 20px 50px rgba(0,0,0,0.5)'
            : '0 8px 30px rgba(0,0,0,0.3)',
          transform: phase === 'enter' ? 'scale(0.3)' : phase === 'hold' ? 'scale(1)' : 'scale(1.02)',
          opacity: phase === 'enter' ? 0 : 1,
          transition: 'all 1.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}
      />
    </div>
  );
}
