import { useState, useMemo, useCallback } from 'react';
import { useStore } from '../store/useStore';
import { Calendar, Check, X as XIcon, Clock, Lock, AlertTriangle, ChevronRight, ChevronLeft, UserMinus, List, Undo2 } from 'lucide-react';

type FilterMode = 'all' | 'group' | 'ungrouped';

// Local undo entry: stores prior state of a single beneficiary's attendance for the selected date
type AttUndoEntry = {
  beneficiaryId: string;
  date: string;
  // 'none' means there was no record before
  prev: 'none' | { id: string; status: 'present' | 'absent' | 'late' };
  // count of changes batched together (for "mark all")
  batch?: AttUndoEntry[];
  label: string;
};

export default function Attendance() {
  const { beneficiaries, groups, attendance, addAttendance, updateAttendance, updateBeneficiary, isAttendanceLocked, currentProjectId } = useStore();
  const [selectedGroup, setSelectedGroup] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [filterMode, setFilterMode] = useState<FilterMode>('group');
  const [undoStack, setUndoStack] = useState<AttUndoEntry[]>([]);

  const projectGroups = useMemo(() => groups.filter((g) => !currentProjectId || g.projectId === currentProjectId), [groups, currentProjectId]);

  // Determine which students to show
  const activeStudents = useMemo(() => {
    const projectStudents = beneficiaries.filter((b) => b.status === 'active' && (!currentProjectId || b.projectId === currentProjectId));
    if (filterMode === 'all') return projectStudents;
    if (filterMode === 'ungrouped') return projectStudents.filter((b) => !b.groupId);
    // filterMode === 'group'
    if (!selectedGroup) return [];
    return projectStudents.filter((b) => b.groupId === selectedGroup);
  }, [beneficiaries, filterMode, selectedGroup, currentProjectId]);

  const getAttendance = useCallback((bid: string) => {
    return attendance.find((a) => a.beneficiaryId === bid && a.date === selectedDate);
  }, [attendance, selectedDate]);

  const toggleAttendance = useCallback((bid: string, status: 'present' | 'absent' | 'late') => {
    const existing = getAttendance(bid);
    const student = beneficiaries.find((b) => b.id === bid);
    const studentName = student?.name || '';
    if (existing) {
      if (isAttendanceLocked(existing)) return;
      // Skip if status didn't actually change
      if (existing.status === status) return;
      const undo: AttUndoEntry = {
        beneficiaryId: bid,
        date: selectedDate,
        prev: { id: existing.id, status: existing.status },
        label: `تعديل حضور: ${studentName}`,
      };
      setUndoStack((s) => [...s.slice(-19), undo]);
      updateAttendance(existing.id, { status });
    } else {
      const undo: AttUndoEntry = {
        beneficiaryId: bid,
        date: selectedDate,
        prev: 'none',
        label: `تسجيل حضور: ${studentName}`,
      };
      setUndoStack((s) => [...s.slice(-19), undo]);
      addAttendance({ beneficiaryId: bid, groupId: student?.groupId || '', date: selectedDate, status, notes: '' });
    }
  }, [getAttendance, isAttendanceLocked, updateAttendance, beneficiaries, addAttendance, selectedDate]);

  const assignToGroup = useCallback((studentId: string, groupId: string) => {
    if (!groupId) return;
    updateBeneficiary(studentId, { groupId }, true);
  }, [updateBeneficiary]);

  // Stats
  const dayAtt = useMemo(() =>
    attendance.filter((a) => a.date === selectedDate && activeStudents.some((s) => s.id === a.beneficiaryId)),
    [attendance, selectedDate, activeStudents]
  );
  const presentCount = dayAtt.filter((a) => a.status === 'present').length;
  const absentCount = dayAtt.filter((a) => a.status === 'absent').length;
  const lateCount = dayAtt.filter((a) => a.status === 'late').length;
  const notRecorded = activeStudents.length - dayAtt.length;

  const isPastDate = (() => {
    const d = new Date(selectedDate + 'T23:59:59');
    return Date.now() - d.getTime() > 86400000;
  })();

  const markAll = useCallback((status: 'present' | 'absent') => {
    if (isPastDate) return;
    const batch: AttUndoEntry[] = [];
    activeStudents.forEach((s) => {
      const existing = getAttendance(s.id);
      if (existing) {
        if (!isAttendanceLocked(existing) && existing.status !== status) {
          batch.push({ beneficiaryId: s.id, date: selectedDate, prev: { id: existing.id, status: existing.status }, label: '' });
          updateAttendance(existing.id, { status });
        }
      } else {
        batch.push({ beneficiaryId: s.id, date: selectedDate, prev: 'none', label: '' });
        addAttendance({ beneficiaryId: s.id, groupId: s.groupId || '', date: selectedDate, status, notes: '' });
      }
    });
    if (batch.length > 0) {
      const undo: AttUndoEntry = {
        beneficiaryId: '',
        date: selectedDate,
        prev: 'none',
        batch,
        label: status === 'present' ? `تحضير الكل (${batch.length})` : `تغييب الكل (${batch.length})`,
      };
      setUndoStack((s) => [...s.slice(-19), undo]);
    }
  }, [activeStudents, getAttendance, isAttendanceLocked, updateAttendance, addAttendance, selectedDate, isPastDate]);

  const performUndo = useCallback(() => {
    if (undoStack.length === 0) return;
    const last = undoStack[undoStack.length - 1];
    const entries = last.batch && last.batch.length > 0 ? last.batch : [last];

    entries.forEach((entry) => {
      // Find the current attendance record (might have changed id if it was created)
      const current = useStore.getState().attendance.find(
        (a) => a.beneficiaryId === entry.beneficiaryId && a.date === entry.date
      );
      if (entry.prev === 'none') {
        // Need to delete: since store has no deleteAttendance, we silently set to a sentinel by calling updateAttendance with a status
        // Instead: call store's set directly to filter it out
        if (current) {
          useStore.setState((s) => ({
            attendance: s.attendance.filter((a) => a.id !== current.id),
          }));
        }
      } else {
        // Restore previous status
        if (current) {
          updateAttendance(current.id, { status: entry.prev.status });
        } else {
          // Record was deleted between actions — re-create
          const student = beneficiaries.find((b) => b.id === entry.beneficiaryId);
          addAttendance({
            beneficiaryId: entry.beneficiaryId,
            groupId: student?.groupId || '',
            date: entry.date,
            status: entry.prev.status,
            notes: '',
          });
        }
      }
    });
    setUndoStack((s) => s.slice(0, -1));
  }, [undoStack, updateAttendance, addAttendance, beneficiaries]);

  const navigateDate = (dir: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + dir);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const isToday = selectedDate === new Date().toISOString().split('T')[0];

  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };
  const inputStyle = { backgroundColor: 'var(--bg-input)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>الحضور والغياب</h2>
        <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>تسجيل الحضور اليومي</p>
      </div>

      {/* Controls */}
      <div className="rounded-2xl border p-3 sm:p-4 space-y-3 transition-colors" style={cardStyle}>
        {/* Filter Mode Tabs */}
        <div>
          <label className="block text-xs font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>عرض الطلاب</label>
          <div className="flex gap-1.5 flex-wrap">
            {[
              { id: 'group' as FilterMode, label: 'حسب المجموعة', icon: List },
              { id: 'all' as FilterMode, label: 'كل الطلاب', icon: Users },
              { id: 'ungrouped' as FilterMode, label: 'بدون مجموعة', icon: UserMinus },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterMode(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  filterMode === tab.id
                    ? 'bg-gradient-to-l from-emerald-500 to-blue-600 text-white shadow-sm'
                    : 'border hover:bg-[var(--bg-card-hover)]'
                }`}
                style={filterMode !== tab.id ? { borderColor: 'var(--border-color)', color: 'var(--text-secondary)' } : {}}
              >
                <tab.icon size={13} />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Group select (only when filterMode === 'group') */}
          {filterMode === 'group' && (
            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>المجموعة</label>
              <select value={selectedGroup} onChange={(e) => setSelectedGroup(e.target.value)} className="w-full px-3.5 py-2.5 border rounded-xl text-sm" style={inputStyle}>
                <option value="">اختر المجموعة</option>
                {projectGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>
          )}

          {/* Date */}
          <div className={filterMode === 'group' ? '' : 'sm:col-span-2'}>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>التاريخ</label>
            <div className="flex items-center gap-2">
              <button onClick={() => navigateDate(1)} className="p-2.5 border rounded-xl hover:bg-[var(--bg-card-hover)] transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                <ChevronRight size={14} style={{ color: 'var(--text-secondary)' }} />
              </button>
              <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="flex-1 px-3.5 py-2.5 border rounded-xl text-sm text-center" style={inputStyle} />
              <button onClick={() => navigateDate(-1)} className="p-2.5 border rounded-xl hover:bg-[var(--bg-card-hover)] transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                <ChevronLeft size={14} style={{ color: 'var(--text-secondary)' }} />
              </button>
            </div>
          </div>
        </div>

        {!isToday && (
          <button onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])} className="text-xs text-blue-500 hover:underline">
            ← العودة لليوم
          </button>
        )}
      </div>

      {/* Date lock warning */}
      {isPastDate && activeStudents.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-3 flex items-center gap-3">
          <Lock size={18} className="text-amber-600 dark:text-amber-400 shrink-0" />
          <div>
            <p className="text-amber-800 dark:text-amber-300 font-medium text-xs">تم قفل التعديل</p>
            <p className="text-amber-600 dark:text-amber-500 text-[10px]">لا يمكن تعديل الحضور بعد مرور 24 ساعة — يمكنك فقط مشاهدة السجل</p>
          </div>
        </div>
      )}

      {/* Stats + Table */}
      {activeStudents.length > 0 && (
        <>
          <div className="grid grid-cols-4 gap-2 sm:gap-3">
            {[
              { icon: Check, label: 'حاضر', count: presentCount, bg: 'from-emerald-500 to-emerald-600' },
              { icon: XIcon, label: 'غائب', count: absentCount, bg: 'from-red-500 to-red-600' },
              { icon: Clock, label: 'متأخر', count: lateCount, bg: 'from-amber-500 to-amber-600' },
              { icon: AlertTriangle, label: 'لم يسجل', count: notRecorded, bg: 'from-slate-400 to-slate-500' },
            ].map((s) => (
              <div key={s.label} className={`bg-gradient-to-br ${s.bg} rounded-xl p-3 text-center text-white`}>
                <s.icon size={16} className="mx-auto mb-1 opacity-80" />
                <p className="text-xl font-bold">{s.count}</p>
                <p className="text-[9px] opacity-80">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Quick Actions — mark all + Undo */}
          {!isPastDate && (
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={() => markAll('present')} className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 text-white text-xs font-bold hover:bg-emerald-600 active:scale-95 transition-all">
                <Check size={14} /> تحضير الكل
              </button>
              <button onClick={() => markAll('absent')} className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-500 text-white text-xs font-bold hover:bg-red-600 active:scale-95 transition-all">
                <XIcon size={14} /> تغييب الكل
              </button>
              <button
                onClick={performUndo}
                disabled={undoStack.length === 0}
                title={undoStack.length > 0 ? `تراجع عن: ${undoStack[undoStack.length - 1].label}` : 'لا يوجد ما يمكن التراجع عنه'}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{
                  backgroundColor: undoStack.length > 0 ? 'var(--bg-card)' : 'var(--bg-input)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-primary)',
                }}
              >
                <Undo2 size={14} />
                تراجع{undoStack.length > 0 ? ` (${undoStack.length})` : ''}
              </button>
              <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>أو اضغط على اسم الطالب للتحضير السريع</span>
            </div>
          )}

          <div className="rounded-2xl border overflow-hidden transition-colors" style={cardStyle}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-input)' }} className="border-b">
                    {['م','الطالب','الرقم','الحالة','إجراء'].map((h) => (
                      <th key={h} className={`px-3 py-3 text-[11px] font-bold whitespace-nowrap ${h === 'الحالة' || h === 'إجراء' ? 'text-center' : 'text-right'}`} style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {activeStudents.map((student, idx) => {
                    const record = getAttendance(student.id);
                    const status = record?.status || '';
                    const locked = record ? isAttendanceLocked(record) : isPastDate;
                    const badges: Record<string, { bg: string; label: string }> = {
                      present: { bg: 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400', label: 'حاضر ✓' },
                      absent: { bg: 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400', label: 'غائب ✗' },
                      late: { bg: 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400', label: 'متأخر ◷' },
                    };

                    return (
                      <tr key={student.id} className="border-b transition-colors hover:bg-[var(--bg-card-hover)]" style={{ borderColor: 'var(--border-light)' }}>
                        <td className="px-3 py-2.5 text-xs" style={{ color: 'var(--text-muted)' }}>{idx + 1}</td>
                        <td className="px-3 py-2.5">
                          <div
                            className={`flex items-center gap-2 ${!locked ? 'cursor-pointer select-none active:scale-[0.98]' : ''}`}
                            onClick={() => { if (!locked) toggleAttendance(student.id, status === 'present' ? 'absent' : 'present'); }}
                            title={!locked ? 'اضغط للتحضير السريع' : ''}
                          >
                            <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-colors ${status === 'present' ? 'bg-emerald-500' : status === 'absent' ? 'bg-red-400' : 'bg-gradient-to-br from-blue-500 to-emerald-500'}`}>
                              <span className="text-white font-bold text-[9px]">{student.name.charAt(0)}</span>
                            </div>
                            <div>
                              <span className="text-sm font-medium block" style={{ color: 'var(--text-primary)' }}>{student.name}</span>
                              {/* Show group assignment dropdown for ungrouped students in 'all' mode */}
                              {filterMode === 'all' && !student.groupId && (
                                <select
                                  value=""
                                  onChange={(e) => assignToGroup(student.id, e.target.value)}
                                  className="mt-0.5 text-[9px] px-1.5 py-0.5 rounded border bg-amber-50 dark:bg-amber-900/20 border-amber-200/50 dark:border-amber-800/30 text-amber-700 dark:text-amber-400"
                                >
                                  <option value="">أضف لمجموعة...</option>
                                  {projectGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                                </select>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-2.5 text-xs" style={{ color: 'var(--text-muted)' }}>#{student.number || '—'}</td>
                        <td className="px-3 py-2.5 text-center">
                          {status ? (
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${badges[status]?.bg}`}>
                              {badges[status]?.label}{locked && <Lock size={9} />}
                            </span>
                          ) : <span className="text-xs" style={{ color: 'var(--text-muted)' }}>—</span>}
                        </td>
                        <td className="px-3 py-2.5">
                          <div className="flex items-center justify-center gap-1">
                            {locked ? (
                              <Lock size={13} style={{ color: 'var(--text-muted)' }} />
                            ) : (
                              <>
                                {(['present', 'absent', 'late'] as const).map((s) => {
                                  const colors: Record<string, { active: string }> = {
                                    present: { active: 'bg-emerald-500 text-white shadow-sm scale-110' },
                                    absent: { active: 'bg-red-500 text-white shadow-sm scale-110' },
                                    late: { active: 'bg-amber-500 text-white shadow-sm scale-110' },
                                  };
                                  const Icon = s === 'present' ? Check : s === 'absent' ? XIcon : Clock;
                                  return (
                                    <button
                                      key={s}
                                      onClick={() => toggleAttendance(student.id, s)}
                                      className={`p-1.5 rounded-lg transition-all ${status === s ? colors[s].active : ''}`}
                                      style={status !== s ? { color: 'var(--text-muted)', backgroundColor: 'var(--bg-input)' } : {}}
                                    >
                                      <Icon size={13} />
                                    </button>
                                  );
                                })}
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Empty state */}
      {activeStudents.length === 0 && (
        <div className="rounded-2xl border p-12 text-center transition-colors" style={cardStyle}>
          <Calendar size={44} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
          <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>
            {filterMode === 'group' && !selectedGroup ? 'اختر مجموعة لتسجيل الحضور' : 'لا يوجد طلاب في هذا الفلتر'}
          </p>
        </div>
      )}
    </div>
  );
}

function Users(props: any) {
  return <svg xmlns="http://www.w3.org/2000/svg" width={props.size || 24} height={props.size || 24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
}
