import { useStore } from '../store/useStore';
import { Users, UserCheck, UserX, FolderOpen, Layers, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function Dashboard() {
  const { beneficiaries, projects, groups, settings, setCurrentPage, currentProjectId } = useStore();
  const dark = settings.darkMode;
  const projectBeneficiaries = beneficiaries.filter((b) => !currentProjectId || b.projectId === currentProjectId);
  const projectGroups = groups.filter((g) => !currentProjectId || g.projectId === currentProjectId);

  const activeBeneficiaries = projectBeneficiaries.filter((b) => b.status === 'active');
  const endedBeneficiaries = projectBeneficiaries.filter((b) => b.status === 'ended');
  const archivedBeneficiaries = projectBeneficiaries.filter((b) => b.status === 'archived');

  const groupData = projectGroups.map((g) => ({
    name: g.name,
    count: projectBeneficiaries.filter((b) => b.groupId === g.id && b.status === 'active').length,
  }));

  const projectStatusData = [
    { name: 'نشط', value: projects.filter((p) => p.status === 'active').length },
    { name: 'متوقف', value: projects.filter((p) => p.status === 'paused').length },
    { name: 'منتهي', value: projects.filter((p) => p.status === 'ended').length },
  ].filter((d) => d.value > 0);

  const stats = [
    { label: 'مستفيدين نشطين', value: activeBeneficiaries.length, icon: UserCheck, gradient: 'from-emerald-500 to-emerald-600', shadow: 'shadow-emerald-500/20' },
    { label: 'منتهين', value: endedBeneficiaries.length, icon: UserX, gradient: 'from-red-500 to-red-600', shadow: 'shadow-red-500/20' },
    { label: 'إجمالي', value: projectBeneficiaries.length, icon: Users, gradient: 'from-blue-500 to-blue-600', shadow: 'shadow-blue-500/20' },
    { label: 'المشاريع', value: projects.length, icon: FolderOpen, gradient: 'from-violet-500 to-violet-600', shadow: 'shadow-violet-500/20' },
    { label: 'المجموعات', value: projectGroups.length, icon: Layers, gradient: 'from-amber-500 to-amber-600', shadow: 'shadow-amber-500/20' },
    { label: 'المؤرشفين', value: archivedBeneficiaries.length, icon: TrendingUp, gradient: 'from-slate-500 to-slate-600', shadow: 'shadow-slate-500/20' },
  ];

  const statusColors: Record<string, string> = { active: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400', paused: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400', ended: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400' };
  const statusLabels: Record<string, string> = { active: 'نشط', paused: 'متوقف', ended: 'منتهي' };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>مرحباً بك 👋</h2>
        <p style={{ color: 'var(--text-secondary)' }} className="mt-1 text-sm">نظرة شاملة على أداء النظام</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className={`bg-gradient-to-br ${stat.gradient} rounded-2xl p-4 text-white shadow-lg ${stat.shadow} transition-transform hover:scale-[1.02]`}>
              <Icon size={22} className="mb-2 opacity-80" />
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-[11px] text-white/70 mt-0.5">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'إضافة مستفيد', page: 'add-beneficiary', color: 'from-emerald-500 to-blue-500' },
          { label: 'تسجيل حضور', page: 'attendance', color: 'from-blue-500 to-violet-500' },
          { label: 'عرض التقارير', page: 'reports', color: 'from-violet-500 to-pink-500' },
          { label: 'سجل المستفيدين', page: 'beneficiaries', color: 'from-amber-500 to-orange-500' },
        ].map((action) => (
          <button
            key={action.page}
            onClick={() => setCurrentPage(action.page)}
            className={`bg-gradient-to-l ${action.color} text-white rounded-2xl p-4 text-sm font-bold text-right hover:shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98]`}
          >
            {action.label} ←
          </button>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-2xl p-5 shadow-[var(--shadow-sm)] border transition-colors" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
          <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text-primary)' }}>توزيع المستفيدين حسب المجموعات</h3>
          {groupData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={groupData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke={dark ? '#334155' : '#f1f5f9'} />
                <XAxis type="number" tick={{ fill: dark ? '#94a3b8' : '#64748b', fontSize: 11 }} />
                <YAxis dataKey="name" type="category" width={110} tick={{ fill: dark ? '#94a3b8' : '#64748b', fontSize: 11 }} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 8px 25px rgba(0,0,0,0.15)', backgroundColor: dark ? '#1e293b' : '#fff', color: dark ? '#e2e8f0' : '#1e293b' }} />
                <Bar dataKey="count" name="عدد المستفيدين" radius={[0, 8, 8, 0]}>
                  {groupData.map((_e, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center" style={{ color: 'var(--text-muted)' }}>لا توجد بيانات</div>
          )}
        </div>

        <div className="rounded-2xl p-5 shadow-[var(--shadow-sm)] border transition-colors" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
          <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text-primary)' }}>حالة المشاريع</h3>
          {projectStatusData.length > 0 ? (
            <div className="flex items-center gap-4">
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={projectStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={95} paddingAngle={5} dataKey="value">
                    {projectStatusData.map((_e, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 8px 25px rgba(0,0,0,0.15)', backgroundColor: dark ? '#1e293b' : '#fff', color: dark ? '#e2e8f0' : '#1e293b' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-3 shrink-0">
                {projectStatusData.map((item, i) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                    <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{item.name}</span>
                    <span className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center" style={{ color: 'var(--text-muted)' }}>لا توجد مشاريع</div>
          )}
        </div>
      </div>

      {/* Projects List */}
      <div className="rounded-2xl p-5 shadow-[var(--shadow-sm)] border transition-colors" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
        <h3 className="text-base font-bold mb-4" style={{ color: 'var(--text-primary)' }}>المشاريع</h3>
        <div className="space-y-2.5">
          {projects.map((project) => {
            const count = projectBeneficiaries.filter((b) => b.projectId === project.id && b.status === 'active').length;
            return (
              <div key={project.id} className="flex items-center justify-between p-3.5 rounded-xl transition-colors" style={{ backgroundColor: 'var(--bg-input)' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                    <FolderOpen size={18} className="text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>{project.name}</p>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{count} مستفيد نشط</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${statusColors[project.status]}`}>
                  {statusLabels[project.status]}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
