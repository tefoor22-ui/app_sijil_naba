import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Lock, LogIn, Plus, ShieldCheck, Eye, EyeOff, ImagePlus, X as XIcon } from 'lucide-react';
import AppleToggle from './AppleToggle';

function compressImage(file: File, maxW = 1200, maxH = 800, quality = 0.8): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let w = img.width, h = img.height;
        if (w > maxW) { h = (maxW / w) * h; w = maxW; }
        if (h > maxH) { w = (maxH / h) * w; h = maxH; }
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d')!.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
}

const emptyProject: Omit<import('../store/useStore').Project, 'id' | 'createdAt'> = {
  name: '',
  description: '',
  status: 'active' as const,
  startDate: '',
  endDate: '',
  protectionType: 'pin' as const,
  credential: '',
  locked: false,
  coverImage: '',
};

export default function StartScreen() {
  const { projects, createProtectedProject, verifyProjectAccess, updateProject } = useStore();
  const [mode, setMode] = useState<'home' | 'create' | 'open'>('home');
  const [form, setForm] = useState({ ...emptyProject });
  const [isProtected, setIsProtected] = useState(false);
  const [selectedProject, setSelectedProject] = useState('');
  const [credential, setCredential] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const cardStyle = { backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' };

  const createProject = () => {
    setError('');
    if (!form.name.trim()) return setError('اسم المشروع مطلوب');
    
    const finalForm = { ...form };
    if (isProtected) {
      if (!(form.credential || '').trim()) return setError('رمز الدخول مطلوب');
      if (form.protectionType === 'pin' && !/^\d{4}$/.test(form.credential || '')) return setError('رمز PIN يجب أن يكون 4 أرقام');
    } else {
      finalForm.protectionType = undefined;
      finalForm.credential = '';
    }
    createProtectedProject(finalForm);
  };

  const openProject = () => {
    setError('');
    if (!selectedProject) return setError('اختر مشروعاً');
    const project = projects.find((p) => p.id === selectedProject);
    if (project?.locked) return setError('هذا المشروع مقفل حالياً');
    
    if (project?.credential) {
      if (!verifyProjectAccess(selectedProject, credential)) setError('بيانات الدخول غير صحيحة');
    } else {
      verifyProjectAccess(selectedProject, '');
    }
  };

  const selected = projects.find((p) => p.id === selectedProject);

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-3xl space-y-5">
        <div className="text-center">
          <img src="/logo.png" alt="سِجلّ" className="w-16 h-16 rounded-[18px] shadow-lg mx-auto mb-4" draggable={false} />
          <h1 className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>سِجلّ</h1>
          <p className="text-sm mt-2" style={{ color: 'var(--text-secondary)' }}>ابدأ بإنشاء مشروع جديد أو ادخل إلى مشروع محفوظ</p>
        </div>

        {mode === 'home' && (
          <div className="grid sm:grid-cols-2 gap-4">
            <button onClick={() => setMode('create')} className="rounded-3xl border p-6 text-right hover:scale-[1.01] active:scale-[0.99] transition-all" style={cardStyle}>
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center mb-4">
                <Plus size={24} className="text-emerald-600 dark:text-emerald-400" />
              </div>
              <h2 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>إنشاء مشروع جديد</h2>
              <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>أنشئ مشروعاً محمياً برمز PIN أو كلمة مرور</p>
            </button>
            <button onClick={() => setMode('open')} className="rounded-3xl border p-6 text-right hover:scale-[1.01] active:scale-[0.99] transition-all" style={cardStyle}>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center mb-4">
                <LogIn size={24} className="text-blue-600 dark:text-blue-400" />
              </div>
              <h2 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>الدخول إلى مشروع محفوظ</h2>
              <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{projects.length} مشروع محفوظ</p>
            </button>
          </div>
        )}

        {mode === 'create' && (
          <div className="rounded-3xl border p-5 sm:p-6" style={cardStyle}>
            <h2 className="font-bold text-lg mb-4" style={{ color: 'var(--text-primary)' }}>إنشاء مشروع جديد</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>اسم المشروع <span className="text-red-500">*</span></label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="field-input" placeholder="اسم المشروع" />
              </div>
              <div className="flex flex-row gap-3 items-start sm:col-span-2 w-full">
                <div className="flex-1 basis-0 min-w-0">
                  <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>تاريخ البداية</label>
                  <input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} className="field-input" />
                </div>
                <div className="flex-1 basis-0 min-w-0">
                  <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>تاريخ النهاية</label>
                  <input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} className="field-input" />
                </div>
              </div>
              
              {/* Optional Protection Toggle */}
              <div className="sm:col-span-2 flex items-center justify-between rounded-xl p-3 border border-slate-200/50 dark:border-slate-700/50" style={{ backgroundColor: 'var(--bg-input)' }}>
                <div>
                  <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>تفعيل حماية المشروع</p>
                  <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>حماية بيانات المشروع برمز PIN أو كلمة مرور</p>
                </div>
                <AppleToggle checked={isProtected} onChange={() => setIsProtected(!isProtected)} size="sm" />
              </div>

              {isProtected && (
                <>
                  <div>
                    <label className="text-xs font-semibold" style={{ color: 'var(--text-secondary)' }}>نوع الحماية</label>
                    <select value={form.protectionType} onChange={(e) => setForm({ ...form, protectionType: e.target.value as 'pin' | 'password', credential: '' })} className="field-input mt-1">
                      <option value="pin">PIN من 4 أرقام</option>
                      <option value="password">كلمة مرور</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold" style={{ color: 'var(--text-secondary)' }}>{form.protectionType === 'pin' ? 'رمز PIN' : 'كلمة المرور'}</label>
                    <input
                      type={form.protectionType === 'pin' ? 'tel' : showPassword ? 'text' : 'password'}
                      inputMode={form.protectionType === 'pin' ? 'numeric' : 'text'}
                      maxLength={form.protectionType === 'pin' ? 4 : undefined}
                      value={form.credential}
                      onChange={(e) => setForm({ ...form, credential: form.protectionType === 'pin' ? e.target.value.replace(/\D/g, '') : e.target.value })}
                      placeholder={form.protectionType === 'pin' ? '1234' : 'أدخل كلمة المرور'}
                      className="field-input mt-1"
                    />
                  </div>
                </>
              )}

              <div className="sm:col-span-2 flex items-center justify-between rounded-xl p-3 border border-slate-200/50 dark:border-slate-700/50" style={{ backgroundColor: 'var(--bg-input)' }}>
                <div>
                  <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>قفل المشروع (إيقاف التشغيل)</p>
                  <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>منع أي تعديلات أو إضافة طلاب حالياً</p>
                </div>
                <AppleToggle checked={Boolean(form.locked)} onChange={() => setForm({ ...form, locked: !form.locked })} size="sm" />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-semibold" style={{ color: 'var(--text-secondary)' }}>وصف المشروع</label>
                <textarea value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="field-input mt-1" placeholder="وصف مختصر للمشروع (اختياري)..." />
              </div>

              {/* Cover Image — optional */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>صورة غلاف المشروع (اختياري)</label>
                {form.coverImage ? (
                  <div className="relative rounded-xl overflow-hidden border" style={{ borderColor: 'var(--border-color)' }}>
                    <img src={form.coverImage} alt="غلاف" className="w-full h-40 object-cover" />
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, coverImage: '' })}
                      className="absolute top-2 left-2 w-7 h-7 bg-black/50 hover:bg-black/70 text-white rounded-lg flex items-center justify-center transition-colors"
                    >
                      <XIcon size={14} />
                    </button>
                    <label className="absolute bottom-2 left-2 px-3 py-1.5 bg-black/50 hover:bg-black/70 text-white text-[10px] font-bold rounded-lg cursor-pointer transition-colors">
                      تغيير
                      <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={async (e) => {
                        const f = e.target.files?.[0]; if (!f || f.size > 5 * 1024 * 1024) return;
                        const compressed = await compressImage(f);
                        setForm({ ...form, coverImage: compressed });
                      }} />
                    </label>
                  </div>
                ) : (
                  <label className="flex flex-col items-center justify-center gap-2 py-8 rounded-xl border-2 border-dashed cursor-pointer transition-colors hover:bg-[var(--bg-card-hover)]" style={{ borderColor: 'var(--border-color)' }}>
                    <ImagePlus size={28} style={{ color: 'var(--text-muted)' }} />
                    <span className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>اضغط لإضافة صورة غلاف</span>
                    <span className="text-[9px]" style={{ color: 'var(--text-muted)' }}>PNG, JPG, WebP — الحد الأقصى 5MB</span>
                    <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={async (e) => {
                      const f = e.target.files?.[0]; if (!f || f.size > 5 * 1024 * 1024) return;
                      const compressed = await compressImage(f);
                      setForm({ ...form, coverImage: compressed });
                    }} />
                  </label>
                )}
              </div>
            </div>
            {error && <p className="text-red-500 text-xs mt-3 font-medium">{error}</p>}
            <div className="flex gap-2 mt-5">
              <button onClick={createProject} className="px-5 py-3 rounded-xl bg-gradient-to-l from-emerald-500 to-blue-600 text-white text-sm font-bold shadow-md hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all">إنشاء ودخول</button>
              <button onClick={() => setMode('home')} className="px-5 py-3 rounded-xl text-sm border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors" style={{ backgroundColor: 'var(--bg-card)', color: 'var(--text-secondary)' }}>رجوع</button>
            </div>
          </div>
        )}

        {mode === 'open' && (
          <div className="rounded-3xl border p-5 sm:p-6" style={cardStyle}>
            <h2 className="font-bold text-lg mb-4" style={{ color: 'var(--text-primary)' }}>الدخول إلى مشروع محفوظ</h2>
            {projects.length === 0 ? (
              <div className="text-center py-8">
                <ShieldCheck size={40} className="mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
                <p style={{ color: 'var(--text-secondary)' }}>لا توجد مشاريع محفوظة</p>
              </div>
            ) : (
              <div className="space-y-3">
                <select value={selectedProject} onChange={(e) => { setSelectedProject(e.target.value); setCredential(''); setError(''); }} className="field-input">
                  <option value="">اختر المشروع</option>
                  {projects.map((p) => <option key={p.id} value={p.id}>{p.name}{p.locked ? ' — مقفل' : ''}{!p.credential ? ' (بدون حماية)' : ''}</option>)}
                </select>
                
                {selected && (
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 rounded-xl p-3 border border-slate-200/50 dark:border-slate-700/50" style={{ backgroundColor: 'var(--bg-input)' }}>
                    <div className="flex items-center gap-2">
                      <Lock size={15} className="text-slate-400" />
                      <span className="text-xs" style={{ color: 'var(--text-primary)' }}>
                        حماية المشروع: {selected.credential ? (selected.protectionType === 'pin' ? 'رمز PIN' : 'كلمة مرور') : 'معطلة'}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <button onClick={() => {
                        const nextType = selected.protectionType === 'pin' || !selected.protectionType ? 'password' : 'pin';
                        const nextCredential = window.prompt(nextType === 'pin' ? 'أدخل PIN جديد من 4 أرقام' : 'أدخل كلمة مرور جديدة') || '';
                        if (nextType === 'pin' && nextCredential && !/^\d{4}$/.test(nextCredential)) {
                          alert('PIN الجديد يجب أن يكون 4 أرقام');
                          return;
                        }
                        if (nextCredential.trim()) {
                          updateProject(selected.id, { protectionType: nextType, credential: nextCredential });
                        }
                      }} className="text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline">تغيير الحماية</button>
                      
                      <span className="text-slate-300 dark:text-slate-600 text-xs">|</span>
                      
                      <button onClick={() => updateProject(selected.id, { locked: !selected.locked })} className="text-xs text-amber-600 dark:text-amber-400 font-medium hover:underline">
                        {selected.locked ? 'فتح المشروع' : 'قفل المشروع'}
                      </button>
                      
                      {selected.credential && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600 text-xs">|</span>
                          <button onClick={() => {
                            if (confirm('هل تريد حذف حماية هذا المشروع؟')) {
                              updateProject(selected.id, { protectionType: undefined, credential: '' });
                            }
                          }} className="text-xs text-red-500 font-medium hover:underline">إلغاء الحماية</button>
                        </>
                      )}
                    </div>
                  </div>
                )}
                
                {selected && selected.credential && (
                  <div className="relative">
                    <input
                      type={selected.protectionType === 'pin' ? 'tel' : showPassword ? 'text' : 'password'}
                      inputMode={selected.protectionType === 'pin' ? 'numeric' : 'text'}
                      maxLength={selected.protectionType === 'pin' ? 4 : undefined}
                      value={credential}
                      onChange={(e) => setCredential(selected.protectionType === 'pin' ? e.target.value.replace(/\D/g, '') : e.target.value)}
                      placeholder={selected.protectionType === 'password' ? 'كلمة المرور' : 'رمز PIN من 4 أرقام'}
                      className="field-input"
                    />
                    {selected.protectionType === 'password' && (
                      <button onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }}>
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
            {error && <p className="text-red-500 text-xs mt-3 font-medium">{error}</p>}
            <div className="flex gap-2 mt-5">
              <button onClick={openProject} disabled={projects.length === 0} className="px-5 py-3 rounded-xl bg-gradient-to-l from-emerald-500 to-blue-600 text-white text-sm font-bold disabled:opacity-40">دخول</button>
              <button onClick={() => setMode('home')} className="px-5 py-3 rounded-xl text-sm" style={{ backgroundColor: 'var(--bg-input)', color: 'var(--text-secondary)' }}>رجوع</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}