import { useEffect, useState } from 'react';
import { useStore } from './store/useStore';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import AddBeneficiary from './components/AddBeneficiary';
import BeneficiaryList from './components/BeneficiaryList';
import Projects from './components/Projects';
import Groups from './components/Groups';
import Attendance from './components/Attendance';
import Reports from './components/Reports';
import ArchivePage from './components/ArchivePage';
import ActivityLog from './components/ActivityLog';
import SettingsPage from './components/SettingsPage';
import StartScreen from './components/StartScreen';
import SplashScreen from './components/SplashScreen';
import WelcomeScreen from './components/WelcomeScreen';
import { LogOut, Menu, Moon, Sun } from 'lucide-react';

const pages: Record<string, React.ComponentType> = {
  dashboard: Dashboard,
  'add-beneficiary': AddBeneficiary,
  beneficiaries: BeneficiaryList,
  projects: Projects,
  groups: Groups,
  attendance: Attendance,
  reports: Reports,
  archive: ArchivePage,
  'activity-log': ActivityLog,
  settings: SettingsPage,
};

const pageTitles: Record<string, string> = {
  dashboard: 'لوحة التحكم',
  'add-beneficiary': 'إضافة مستفيد',
  beneficiaries: 'سجل المستفيدين',
  projects: 'المشاريع',
  groups: 'المجموعات',
  attendance: 'الحضور والغياب',
  reports: 'التقارير',
  archive: 'الأرشيف',
  'activity-log': 'سجل العمليات',
  settings: 'الإعدادات',
};

export default function App() {
  const { currentPage, setSidebarOpen, autoArchiveCheck, settings, toggleDarkMode, currentProjectId, projects, leaveProject } = useStore();
  const PageComponent = pages[currentPage] || Dashboard;
  const currentProject = projects.find((p) => p.id === currentProjectId);
  const [splashDone, setSplashDone] = useState(false);

  // Initialize dark mode on load
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  useEffect(() => {
    autoArchiveCheck();
  }, []);

  // === Persistent storage safety net ===
  // Ensure data is saved when the app is backgrounded, hidden, or closed.
  // Critical for iOS Safari which may purge localStorage when the app is suspended.
  useEffect(() => {
    const flushToStorage = () => {
      try {
        const s = useStore.getState();
        localStorage.setItem('beneficiary-system-data', JSON.stringify({
          beneficiaries: s.beneficiaries,
          projects: s.projects,
          groups: s.groups,
          attendance: s.attendance,
          activityLog: s.activityLog,
          settings: s.settings,
        }));
      } catch (err) {
        console.error('flushToStorage failed:', err);
      }
    };

    const onVisibilityChange = () => { if (document.visibilityState === 'hidden') flushToStorage(); };
    const onPageHide = () => flushToStorage();
    const onBeforeUnload = () => flushToStorage();
    const onBlur = () => flushToStorage();
    const onFreeze = () => flushToStorage();

    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pagehide', onPageHide);
    window.addEventListener('beforeunload', onBeforeUnload);
    window.addEventListener('blur', onBlur);
    document.addEventListener('freeze', onFreeze as any);

    // Also flush on a periodic interval (every 10s) as extra insurance
    const interval = setInterval(flushToStorage, 10000);

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pagehide', onPageHide);
      window.removeEventListener('beforeunload', onBeforeUnload);
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('freeze', onFreeze as any);
      clearInterval(interval);
      // Final flush on unmount
      flushToStorage();
    };
  }, []);

  // Request persistent storage from the browser (prevents iOS from clearing data)
  useEffect(() => {
    if ('storage' in navigator && 'persist' in navigator.storage) {
      navigator.storage.persist().catch(() => { /* ignore */ });
    }
  }, []);

  if (!splashDone) {
    return <SplashScreen onFinish={() => setSplashDone(true)} />;
  }

  if (!settings.hasSeenWelcome) {
    return <WelcomeScreen />;
  }

  if (!currentProjectId) {
    return <StartScreen />;
  }

  return (
    <div className="min-h-screen transition-colors duration-300 bg-[var(--bg-primary)]" dir="rtl">
      <Sidebar />

      <div className="lg:mr-[280px] min-h-screen">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 border-b transition-colors duration-300"
          style={{ backgroundColor: settings.darkMode ? 'rgba(15,23,42,0.85)' : 'rgba(255,255,255,0.85)', borderColor: 'var(--border-color)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}>
          <div className="flex items-center justify-between px-4 py-3 lg:px-6">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-xl transition-colors hover:bg-[var(--bg-card-hover)]">
                <Menu size={22} style={{ color: 'var(--text-primary)' }} />
              </button>
              <div>
                <h1 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                  {pageTitles[currentPage] || 'لوحة التحكم'}
                </h1>
                <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{currentProject?.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {/* Dark Mode Toggle */}
              <button onClick={toggleDarkMode} className="p-2 rounded-xl transition-colors hover:bg-[var(--bg-card-hover)]">
                {settings.darkMode
                  ? <Sun size={19} className="text-amber-400" />
                  : <Moon size={19} style={{ color: 'var(--text-secondary)' }} />
                }
              </button>
              <button onClick={leaveProject} className="p-2 rounded-xl transition-colors hover:bg-[var(--bg-card-hover)]" title="الخروج من المشروع">
                <LogOut size={19} style={{ color: 'var(--text-secondary)' }} />
              </button>
              {/* Logo */}
              <img src="/logo.png" alt="سِجلّ" className="w-9 h-9 rounded-[10px] shadow-sm" draggable={false} />
            </div>
          </div>
        </header>

        <main className="p-4 lg:p-6 animate-fade-in">
          <PageComponent />
        </main>
      </div>
    </div>
  );
}
